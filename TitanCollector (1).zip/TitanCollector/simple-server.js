const express = require('express');
const path = require('path');
const app = express();
const PORT = 8080; // Use different port to avoid conflicts

app.use(express.static('.'));
app.use(express.json());

// Serve the main interface
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Basic health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'Titan Collection System - Data Integrity Mode' });
});

// Mock integration endpoints for demo
app.get('/api/integration/check-connection', (req, res) => {
  res.json({
    status: 'connected',
    statusCode: 200,
    url: 'https://www.compliantcollection.com',
    timestamp: new Date().toISOString()
  });
});

app.post('/api/integration/pull-debtors', (req, res) => {
  res.json({
    message: 'No accounts found in test mode - connect to real Compliant Collection system for data',
    debtors: [],
    workingEndpoint: '/api/test',
    timestamp: new Date().toISOString()
  });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Titan Collection System running on port ${PORT}`);
  console.log(`Access via Replit preview or http://localhost:${PORT}`);
}).on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.log(`Port ${PORT} in use, trying ${PORT + 1}...`);
    app.listen(PORT + 1, '0.0.0.0');
  }
});