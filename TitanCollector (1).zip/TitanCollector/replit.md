# Replit.md

## Overview

**Titan Collection System** - A modular, multi-tenant debt collection management system built specifically for Compliant Collection LLC, with architecture designed for potential future sales to other companies. 

The system provides professional debt collection management with API-driven integration to communicate with the existing file application. Built with React 19, Express.js, and TypeScript throughout.

**Integration Status: LIVE** ✅ Successfully connected to www.compliantcollection.com with working JSON API endpoints that automatically sync debtor data between systems.

## User Preferences

Preferred communication style: Simple, everyday language.

## Business Context

- **Primary Client**: Compliant Collection LLC (existing client with file application)
- **Primary Goal**: Build comprehensive debt collection system for Compliant Collection LLC
- **Secondary Goal**: Keep architecture modular and white-labelable for potential future sales
- **Integration Requirement**: Must communicate with existing file application built on Replit

## System Architecture

### Frontend Architecture
- **Framework**: React 19 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Routing**: Wouter for lightweight client-side routing
- **Styling**: Tailwind CSS with PostCSS for utility-first styling
- **UI Components**: Radix UI for accessible, unstyled components
- **State Management**: TanStack React Query for server state management
- **Forms**: React Hook Form with Zod validation and Hookform resolvers
- **API Integration**: Axios client for file application communication

### Backend Architecture
- **Framework**: Express.js 5.x with TypeScript
- **Security**: Helmet for security headers, CORS for cross-origin requests
- **Database**: In-memory storage (MemStorage) with Drizzle ORM schema for future database migration
- **Validation**: Zod for runtime type checking and validation
- **Environment**: dotenv for environment variable management
- **Integration Services**: File System Integration service for bi-directional communication

### Integration Architecture
- **File System Communication**: Dedicated API client and server integration
- **Webhook Support**: Handles real-time updates from file application
- **Data Sync**: Automatic syncing of debtor records, contact logs, and payments
- **Adapter Pattern**: Pluggable backend connectors for different systems

## Key Components

### Frontend Components
- **UI Library**: Radix UI primitives (Dialog, Select, Slot, Toast)
- **Form Handling**: React Hook Form with Zod schema validation
- **Styling System**: Tailwind CSS with class-variance-authority for component variants
- **Icons**: Lucide React for consistent iconography
- **Utility Functions**: clsx and tailwind-merge for conditional styling

### Backend Components
- **Web Server**: Express.js with security middleware
- **Database Layer**: Drizzle ORM with Zod integration for schema validation
- **Security**: Helmet and CORS middleware for protection
- **Configuration**: Environment-based configuration with dotenv

## Data Flow

1. **Client-Side**: React components use React Hook Form for form state management
2. **Validation**: Zod schemas validate data both client and server-side
3. **API Communication**: TanStack React Query manages server state and caching
4. **Server Processing**: Express.js handles HTTP requests with middleware pipeline
5. **Storage Operations**: MemStorage provides in-memory data persistence
6. **File System Integration**: Automatic bi-directional sync with existing file application
7. **External API Integration**: Pluggable adapters for third-party debt collection systems
8. **Response Handling**: JSON responses with proper error handling and validation

## Integration Points

### File Application Communication
- **Debtor Sync**: Automatic creation/update of files when debtors are added/modified
- **Contact Logs**: Upload contact history as documents to relevant files
- **Payment Records**: Sync payment information to file system
- **Document Management**: Leverage existing document storage capabilities
- **Search Integration**: Find existing files by debtor information
- **Webhook Handling**: Real-time updates from file system changes

### Multi-Tenant Features
- **White Labeling**: Customizable branding, colors, and logos per tenant
- **API Configuration**: Tenant-specific API endpoints and credentials
- **Compliance Templates**: Tenant-specific scripts and disclosure requirements
- **User Management**: Role-based access per tenant organization

## External Dependencies

### Core Runtime
- React 19 ecosystem (react, react-dom)
- Express.js with security middleware (helmet, cors)
- TypeScript for type safety

### Database & Validation
- Drizzle ORM for database operations
- Zod for schema validation and type inference
- Drizzle-Zod for seamless integration

### Development & Build Tools
- Vite for development server and build process
- TypeScript compiler
- Tailwind CSS with PostCSS for styling
- Autoprefixer for CSS vendor prefixes

### UI & Form Libraries
- Radix UI component primitives
- React Hook Form for form management
- TanStack React Query for server state
- Lucide React for icons

## Deployment Strategy

The application is structured as a monorepo with both frontend and backend dependencies in a single package.json. This suggests:

1. **Development**: Likely uses Vite's dev server for frontend and a separate Express server
2. **Build Process**: Vite handles frontend bundling, TypeScript compilation for both layers
3. **Environment**: Uses dotenv for environment configuration
4. **Database**: Drizzle ORM suggests database-agnostic approach (PostgreSQL likely target)

The architecture supports modern development practices with type safety, server-side rendering capabilities, and optimized production builds. The choice of lightweight libraries (Wouter vs React Router, Drizzle vs heavier ORMs) indicates a focus on performance and bundle size optimization.

## Recent Changes

**July 22, 2025 - System Shutdown - Technical Issues:**
- ❌ **Replit Preview System Issues**: Multiple attempts to get preview working failed despite servers running correctly
- ❌ **Port Conflicts**: Persistent server conflicts preventing stable operation
- 🔄 **Status**: System shut down due to fundamental preview/server connectivity issues
- ✅ **Data Integrity Achieved**: Successfully removed all sample data and enforced authentic-data-only policy
- ✅ **Code Complete**: All server endpoints and data integrity logic implemented and ready

**July 21, 2025 - Integration Completion:**
- ✅ Successfully integrated with Compliant Collection file system at www.compliantcollection.com
- ✅ Built and tested API endpoints for real-time debtor data synchronization
- ✅ Integration dashboard created with connection testing and one-click import functionality