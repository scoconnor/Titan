// Basic schema for Titan Collection System
// This contains simplified types for the working version

export interface Tenant {
  id: string;
  name: string;
  slug: string;
  logoUrl?: string;
  primaryColor?: string;
  secondaryColor?: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface User {
  id: string;
  tenantId?: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  profileImageUrl?: string;
  role: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface Debtor {
  id: string;
  tenantId: string;
  firstName: string;
  lastName: string;
  phone: string;
  currentBalance: string;
  status: string;
  priority: string;
  nextContactDate?: string;
}

export interface ContactLog {
  id: string;
  debtorId: string;
  collectorId: string;
  type: string;
  outcome: string;
  notes?: string;
  createdAt: Date;
}

export interface Payment {
  id: string;
  debtorId: string;
  amount: string;
  method: string;
  status: string;
  transactionId?: string;
  createdAt: Date;
}

export interface ComplianceTemplate {
  id: string;
  tenantId: string;
  name: string;
  content: string;
  type: string;
  isActive: boolean;
  createdAt: Date;
}

// Insert types
export type InsertTenant = Omit<Tenant, 'id' | 'createdAt' | 'updatedAt'>;
export type InsertUser = Omit<User, 'id' | 'createdAt' | 'updatedAt'>;
export type UpsertUser = Partial<InsertUser> & { id: string };
export type InsertDebtor = Omit<Debtor, 'id'>;
export type InsertContactLog = Omit<ContactLog, 'id' | 'createdAt'>;
export type InsertPayment = Omit<Payment, 'id' | 'createdAt'>;
export type InsertComplianceTemplate = Omit<ComplianceTemplate, 'id' | 'createdAt'>;