#!/bin/bash
# Simple startup script for Titan Collection System
echo "Starting Titan Collection System..."
cd /home/runner/workspace
exec node start-titan.js