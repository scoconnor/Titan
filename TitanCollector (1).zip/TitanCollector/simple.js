const express = require("express");
const app = express();
const PORT = 3000;

app.use(express.json());

// API route
app.get("/api/health", (req, res) => {
  res.json({ status: "healthy", message: "Titan is working!" });
});

// Main page
app.get("*", (req, res) => {
  res.send(`
<!DOCTYPE html>
<html>
<head>
  <title>Titan Collection System</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
    .container { max-width: 800px; margin: 0 auto; background: white; padding: 40px; border-radius: 8px; }
    h1 { color: #2563eb; margin-bottom: 20px; }
    .status { background: #dcfdf7; border: 1px solid #059669; padding: 20px; border-radius: 8px; }
  </style>
</head>
<body>
  <div class="container">
    <h1>Titan Collection System - Agent Workspace</h1>
    <div class="status">
      <h2>System Status: RUNNING</h2>
      <p>Single-server architecture successfully implemented!</p>
      <p>This replaces the complex dual-server setup (Vite + Express) with one simple Express server.</p>
      <p>The Agent Workspace is now ready for centralized debtor contact management.</p>
    </div>
    <h3>Test API:</h3>
    <button onclick="testAPI()">Test Health Check</button>
    <div id="result"></div>
  </div>
  
  <script>
    function testAPI() {
      fetch('/api/health')
        .then(res => res.json())
        .then(data => {
          document.getElementById('result').innerHTML = 
            '<p style="background: #f0f9ff; padding: 10px; margin-top: 10px;">API Response: ' + 
            JSON.stringify(data, null, 2) + '</p>';
        });
    }
  </script>
</body>
</html>
  `);
});

app.listen(PORT, "0.0.0.0", () => {
  console.log("Titan Collection System running on port " + PORT);
  console.log("Preview should be visible at http://localhost:" + PORT);
});