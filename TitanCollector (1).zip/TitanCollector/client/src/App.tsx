import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ThemeProvider } from "./providers/ThemeProvider";
import Dashboard from "./pages/Dashboard";
import Integration from "./pages/Integration";
import Agent from "./pages/Agent";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      retry: false,
    },
  },
});

function App() {
  const currentPage = window.location.hash || "#dashboard";
  
  const renderPage = () => {
    switch (currentPage) {
      case "#integration":
        return <Integration />;
      case "#agent":
        return <Agent />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <div className="min-h-screen bg-background text-foreground">
          <nav className="border-b bg-white dark:bg-gray-900">
            <div className="px-6 py-3">
              <div className="flex items-center gap-6">
                <h1 className="text-xl font-bold text-blue-600">Titan Collection</h1>
                <div className="flex gap-4">
                  <a 
                    href="#dashboard" 
                    className={`px-3 py-1 rounded ${currentPage === "#dashboard" ? "bg-blue-100 text-blue-800" : "text-gray-600 hover:text-blue-600"}`}
                    onClick={() => window.location.reload()}
                  >
                    Dashboard
                  </a>
                  <a 
                    href="#integration" 
                    className={`px-3 py-1 rounded ${currentPage === "#integration" ? "bg-blue-100 text-blue-800" : "text-gray-600 hover:text-blue-600"}`}
                    onClick={() => window.location.reload()}
                  >
                    Integration
                  </a>
                  <a 
                    href="#agent" 
                    className={`px-3 py-1 rounded ${currentPage === "#agent" ? "bg-blue-100 text-blue-800" : "text-gray-600 hover:text-blue-600"}`}
                    onClick={() => window.location.reload()}
                  >
                    Agent Workspace
                  </a>
                </div>
              </div>
            </div>
          </nav>
          {renderPage()}
        </div>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;