import axios from "axios";

// API client for communicating with the main file application
export const api = axios.create({
  baseURL: process.env.MAIN_PLATFORM_URL || "https://your-main-platform.com/api",
  headers: {
    Authorization: `Bearer ${localStorage.getItem('employeeToken')}`,
    'Content-Type': 'application/json',
  },
});

// Request interceptor to ensure fresh tokens
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('employeeToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Token expired or invalid
      localStorage.removeItem('employeeToken');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// File application API endpoints
export const fileApiEndpoints = {
  // Employee/User management
  getEmployee: (id: string) => api.get(`/employees/${id}`),
  getEmployees: () => api.get('/employees'),
  
  // File/Case management  
  getFiles: (params?: any) => api.get('/files', { params }),
  getFile: (id: string) => api.get(`/files/${id}`),
  createFile: (data: any) => api.post('/files', data),
  updateFile: (id: string, data: any) => api.patch(`/files/${id}`, data),
  
  // Document management
  getDocuments: (fileId: string) => api.get(`/files/${fileId}/documents`),
  uploadDocument: (fileId: string, formData: FormData) => 
    api.post(`/files/${fileId}/documents`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    }),
  
  // Search and sync
  searchFiles: (query: string) => api.get('/files/search', { params: { q: query } }),
  syncDebtorData: (debtorId: string) => api.get(`/sync/debtor/${debtorId}`),
};

// Titan-specific API calls to main platform
export const titanIntegration = {
  // Sync debtor information from file system
  syncDebtor: async (externalId: string) => {
    try {
      const response = await fileApiEndpoints.getFile(externalId);
      return response.data;
    } catch (error) {
      console.error('Failed to sync debtor from file system:', error);
      return null;
    }
  },

  // Create a new file/case when adding debtor
  createDebtorFile: async (debtorData: any) => {
    try {
      const fileData = {
        clientName: `${debtorData.firstName} ${debtorData.lastName}`,
        fileType: 'debt-collection',
        status: 'active',
        assignedTo: debtorData.assignedCollectorId,
        metadata: {
          originalAmount: debtorData.originalAmount,
          currentBalance: debtorData.currentBalance,
          phone: debtorData.phone,
          email: debtorData.email,
          address: debtorData.address,
        }
      };
      
      const response = await fileApiEndpoints.createFile(fileData);
      return response.data;
    } catch (error) {
      console.error('Failed to create debtor file:', error);
      return null;
    }
  },

  // Upload contact logs as documents
  uploadContactLog: async (fileId: string, contactLog: any) => {
    try {
      const logData = new Blob([JSON.stringify(contactLog, null, 2)], 
        { type: 'application/json' });
      const formData = new FormData();
      formData.append('file', logData, `contact-log-${new Date().toISOString()}.json`);
      formData.append('documentType', 'contact-log');
      formData.append('description', `Contact log - ${contactLog.contactType} on ${new Date(contactLog.createdAt).toLocaleDateString()}`);
      
      const response = await fileApiEndpoints.uploadDocument(fileId, formData);
      return response.data;
    } catch (error) {
      console.error('Failed to upload contact log:', error);
      return null;
    }
  },

  // Search for existing files by debtor info
  findDebtorFile: async (firstName: string, lastName: string, phone?: string) => {
    try {
      const searchQuery = `${firstName} ${lastName} ${phone || ''}`.trim();
      const response = await fileApiEndpoints.searchFiles(searchQuery);
      return response.data;
    } catch (error) {
      console.error('Failed to search for debtor file:', error);
      return [];
    }
  }
};