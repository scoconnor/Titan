export default function Payments() {
  return (
    <div className="min-h-screen bg-background p-6">
      <h1 className="text-2xl font-bold">Payments</h1>
      <p className="text-muted-foreground">Coming soon...</p>
    </div>
  );
}