import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { 
  ExternalLink, 
  RefreshCw, 
  Users, 
  CheckCircle,
  AlertCircle,
  Plus
} from "lucide-react";

interface ConnectionStatus {
  status: string;
  statusCode: number;
  url: string;
  timestamp: string;
}

export default function Integration() {
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus | null>(null);
  const [isChecking, setIsChecking] = useState(false);
  const [isPulling, setIsPulling] = useState(false);
  const [pullResult, setPullResult] = useState<any>(null);

  const checkConnection = async () => {
    setIsChecking(true);
    try {
      const response = await fetch("/api/integration/check-connection");
      const data = await response.json();
      setConnectionStatus(data);
    } catch (error) {
      console.error("Error checking connection:", error);
    } finally {
      setIsChecking(false);
    }
  };

  const pullDebtors = async () => {
    setIsPulling(true);
    setPullResult(null);
    try {
      const response = await fetch("/api/integration/pull-debtors", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });
      const data = await response.json();
      setPullResult(data);
    } catch (error) {
      console.error("Error pulling debtors:", error);
      setPullResult({
        message: "Failed to pull debtors",
        error: error.message
      });
    } finally {
      setIsPulling(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "connected":
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Connected</Badge>;
      case "error":
      case "unreachable":
        return <Badge variant="destructive"><AlertCircle className="w-3 h-3 mr-1" />Error</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Compliant Collection Integration</h1>
          <p className="text-muted-foreground">
            Connect and sync data with your Compliant Collection file system
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            onClick={checkConnection}
            disabled={isChecking}
          >
            {isChecking ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <ExternalLink className="w-4 h-4 mr-2" />}
            Check Connection
          </Button>
        </div>
      </div>

      {/* Connection Status */}
      <Card>
        <CardHeader>
          <CardTitle>Connection Status</CardTitle>
          <CardDescription>
            Current status of connection to www.compliantcollection.com
          </CardDescription>
        </CardHeader>
        <CardContent>
          {connectionStatus ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="font-medium">Status:</span>
                {getStatusBadge(connectionStatus.status)}
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">URL:</span>
                <span className="text-sm font-mono">{connectionStatus.url}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Response Code:</span>
                <span className="text-sm">{connectionStatus.statusCode}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Last Checked:</span>
                <span className="text-sm">{new Date(connectionStatus.timestamp).toLocaleString()}</span>
              </div>
            </div>
          ) : (
            <div className="text-center py-4 text-muted-foreground">
              Click "Check Connection" to test connectivity
            </div>
          )}
        </CardContent>
      </Card>

      {/* Data Sync */}
      <Card>
        <CardHeader>
          <CardTitle>Data Synchronization</CardTitle>
          <CardDescription>
            Pull debtor information from your Compliant Collection system into Titan
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <Button 
              onClick={pullDebtors}
              disabled={isPulling || connectionStatus?.status !== "connected"}
            >
              {isPulling ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <Users className="w-4 h-4 mr-2" />}
              Pull Debtors from Compliant Collection
            </Button>
            
            {connectionStatus?.status !== "connected" && (
              <span className="text-sm text-muted-foreground">
                Connection required to sync data
              </span>
            )}
          </div>

          {pullResult && (
            <div className="mt-4 p-4 rounded-lg border">
              <div className="flex items-center gap-2 mb-2">
                {pullResult.error ? (
                  <AlertCircle className="w-4 h-4 text-red-500" />
                ) : (
                  <CheckCircle className="w-4 h-4 text-green-500" />
                )}
                <span className="font-medium">
                  {pullResult.error ? "Sync Failed" : "Sync Completed"}
                </span>
              </div>
              
              <p className="text-sm text-muted-foreground mb-2">
                {pullResult.message}
              </p>

              {pullResult.debtors && (
                <div className="text-sm">
                  <span className="font-medium">Synced {pullResult.debtors.length} debtors:</span>
                  <ul className="mt-2 space-y-1">
                    {pullResult.debtors.slice(0, 5).map((debtor: any) => (
                      <li key={debtor.id} className="flex items-center gap-2">
                        <Plus className="w-3 h-3" />
                        {debtor.firstName} {debtor.lastName} - ${debtor.currentBalance}
                      </li>
                    ))}
                    {pullResult.debtors.length > 5 && (
                      <li className="text-muted-foreground">
                        ...and {pullResult.debtors.length - 5} more
                      </li>
                    )}
                  </ul>
                </div>
              )}

              {pullResult.error && (
                <div className="mt-2 text-sm text-red-600">
                  <strong>Error:</strong> {pullResult.error}
                  {pullResult.suggestion && (
                    <div className="mt-1">
                      <strong>Suggestion:</strong> {pullResult.suggestion}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Integration Instructions */}
      <Card>
        <CardHeader>
          <CardTitle>Manual Integration Steps</CardTitle>
          <CardDescription>
            How to connect your Compliant Collection system with Titan
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 text-sm">
            <div className="space-y-2">
              <h4 className="font-medium">Option 1: API Integration</h4>
              <p className="text-muted-foreground">
                If your Compliant Collection system has API endpoints, we can connect directly:
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground ml-4">
                <li>Ensure API endpoints are available at www.compliantcollection.com/api</li>
                <li>Provide API authentication tokens if required</li>
                <li>Test the connection above and pull data automatically</li>
              </ul>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium">Option 2: Manual Data Entry</h4>
              <p className="text-muted-foreground">
                You can manually add debtors to test the Titan system:
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground ml-4">
                <li>Go to the main dashboard and click "Add Debtor"</li>
                <li>Enter debtor information from your Compliant Collection files</li>
                <li>Titan will manage contact logs and payment tracking</li>
                <li>Changes can be exported back to your file system</li>
              </ul>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium">Option 3: CSV Import</h4>
              <p className="text-muted-foreground">
                Export debtors from Compliant Collection and import to Titan:
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground ml-4">
                <li>Export debtor data as CSV from your system</li>
                <li>Use Titan's bulk import feature</li>
                <li>Map fields automatically</li>
                <li>Review and activate imported accounts</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}