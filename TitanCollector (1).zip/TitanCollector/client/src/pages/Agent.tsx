import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { 
  Phone, 
  Mail, 
  MapPin, 
  DollarSign,
  Clock,
  User,
  FileText,
  Plus
} from "lucide-react";

interface Debtor {
  id: string;
  firstName: string;
  lastName: string;
  phone: string;
  email?: string;
  currentBalance: string;
  originalAmount?: string;
  status: string;
  priority: string;
  nextContactDate?: string;
  lastContactDate?: string;
  address?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  source?: string;
  assignedCollectorId?: string;
}

interface ContactLog {
  id: string;
  debtorId: string;
  contactType: string;
  contactMethod: string;
  outcome: string;
  notes: string;
  duration?: number;
  createdAt: string;
  nextAction?: string;
  nextContactDate?: string;
}

export default function Agent() {
  const [selectedDebtor, setSelectedDebtor] = useState<Debtor | null>(null);
  const [showContactForm, setShowContactForm] = useState(false);
  const queryClient = useQueryClient();

  // Fetch debtors assigned to current agent
  const { data: debtorsData, isLoading: debtorsLoading } = useQuery({
    queryKey: ["/api/debtors"],
  });

  // Fetch contact logs for selected debtor
  const { data: contactLogs = [] } = useQuery({
    queryKey: ["/api/contact-logs", selectedDebtor?.id],
    enabled: !!selectedDebtor,
  });

  const debtors = debtorsData?.debtors || [];
  const myDebtors = debtors.filter((d: Debtor) => d.assignedCollectorId === "current-agent" || !d.assignedCollectorId);

  // Contact attempt mutation
  const contactMutation = useMutation({
    mutationFn: async (contactData: any) => {
      const response = await fetch("/api/contact-logs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(contactData),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contact-logs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/debtors"] });
      setShowContactForm(false);
    },
  });

  const getPriorityColor = (priority: string) => {
    switch (priority?.toLowerCase()) {
      case "high": return "bg-red-100 text-red-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "low": return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case "active": return "bg-blue-100 text-blue-800";
      case "paid": return "bg-green-100 text-green-800";
      case "dispute": return "bg-orange-100 text-orange-800";
      case "legal": return "bg-purple-100 text-purple-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const formatCurrency = (amount: string) => {
    const num = parseFloat(amount.replace(/[,$]/g, ""));
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(num);
  };

  const ContactForm = ({ debtor, onClose }: { debtor: Debtor; onClose: () => void }) => {
    const [formData, setFormData] = useState({
      contactType: "outbound",
      contactMethod: "phone",
      outcome: "",
      notes: "",
      duration: "",
      nextAction: "",
      nextContactDate: "",
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      contactMutation.mutate({
        debtorId: debtor.id,
        ...formData,
        duration: formData.duration ? parseInt(formData.duration) : undefined,
      });
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg p-6 w-full max-w-md">
          <h3 className="text-lg font-semibold mb-4">
            Log Contact - {debtor.firstName} {debtor.lastName}
          </h3>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Contact Method</label>
              <select
                value={formData.contactMethod}
                onChange={(e) => setFormData({ ...formData, contactMethod: e.target.value })}
                className="w-full p-2 border rounded"
              >
                <option value="phone">Phone</option>
                <option value="email">Email</option>
                <option value="letter">Letter</option>
                <option value="sms">SMS</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Outcome</label>
              <select
                value={formData.outcome}
                onChange={(e) => setFormData({ ...formData, outcome: e.target.value })}
                className="w-full p-2 border rounded"
                required
              >
                <option value="">Select outcome...</option>
                <option value="contact-made">Contact Made</option>
                <option value="no-answer">No Answer</option>
                <option value="voicemail">Voicemail Left</option>
                <option value="busy">Busy Signal</option>
                <option value="payment-promise">Payment Promise</option>
                <option value="dispute">Dispute Raised</option>
                <option value="payment-received">Payment Received</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Duration (minutes)</label>
              <input
                type="number"
                value={formData.duration}
                onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                className="w-full p-2 border rounded"
                min="0"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Notes</label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="w-full p-2 border rounded h-20"
                placeholder="Contact details, debtor response, etc."
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Next Contact Date</label>
              <input
                type="date"
                value={formData.nextContactDate}
                onChange={(e) => setFormData({ ...formData, nextContactDate: e.target.value })}
                className="w-full p-2 border rounded"
              />
            </div>

            <div className="flex gap-2">
              <Button type="submit" disabled={contactMutation.isPending}>
                {contactMutation.isPending ? "Saving..." : "Save Contact"}
              </Button>
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
            </div>
          </form>
        </div>
      </div>
    );
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Agent Workspace</h1>
          <p className="text-muted-foreground">
            Manage your assigned accounts and contact activities
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline">
            <User className="w-3 h-3 mr-1" />
            Agent Dashboard
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Account List */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                My Accounts ({myDebtors.length})
              </CardTitle>
              <CardDescription>
                Accounts assigned to you for collection
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              {debtorsLoading ? (
                <div className="p-4 text-center text-muted-foreground">
                  Loading accounts...
                </div>
              ) : myDebtors.length === 0 ? (
                <div className="p-4 text-center text-muted-foreground">
                  No accounts assigned
                </div>
              ) : (
                <div className="max-h-96 overflow-y-auto">
                  {myDebtors.map((debtor: Debtor) => (
                    <div
                      key={debtor.id}
                      className={`p-4 border-b cursor-pointer hover:bg-gray-50 ${
                        selectedDebtor?.id === debtor.id ? "bg-blue-50 border-blue-200" : ""
                      }`}
                      onClick={() => setSelectedDebtor(debtor)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="font-medium">
                            {debtor.firstName} {debtor.lastName}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {formatCurrency(debtor.currentBalance)}
                          </div>
                          <div className="flex items-center gap-1 mt-1">
                            <Badge className={getPriorityColor(debtor.priority)} variant="secondary">
                              {debtor.priority}
                            </Badge>
                            <Badge className={getStatusColor(debtor.status)} variant="secondary">
                              {debtor.status}
                            </Badge>
                          </div>
                        </div>
                        {debtor.nextContactDate && (
                          <div className="text-xs text-muted-foreground">
                            <Clock className="w-3 h-3 inline mr-1" />
                            {new Date(debtor.nextContactDate).toLocaleDateString()}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Account Details */}
        <div className="lg:col-span-2">
          {selectedDebtor ? (
            <div className="space-y-6">
              {/* Debtor Info Card */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <User className="w-5 h-5" />
                      {selectedDebtor.firstName} {selectedDebtor.lastName}
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      <Button 
                        onClick={() => setShowContactForm(true)}
                        className="flex items-center gap-1"
                      >
                        <Plus className="w-4 h-4" />
                        Log Contact
                      </Button>
                    </div>
                  </div>
                  <CardDescription>
                    Account details and contact information
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Contact Info */}
                    <div className="space-y-3">
                      <h4 className="font-medium">Contact Information</h4>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <Phone className="w-4 h-4 text-muted-foreground" />
                          <span>{selectedDebtor.phone}</span>
                        </div>
                        {selectedDebtor.email && (
                          <div className="flex items-center gap-2">
                            <Mail className="w-4 h-4 text-muted-foreground" />
                            <span>{selectedDebtor.email}</span>
                          </div>
                        )}
                        {selectedDebtor.address && (
                          <div className="flex items-start gap-2">
                            <MapPin className="w-4 h-4 text-muted-foreground mt-0.5" />
                            <div>
                              <div>{selectedDebtor.address}</div>
                              {(selectedDebtor.city || selectedDebtor.state) && (
                                <div>
                                  {selectedDebtor.city}, {selectedDebtor.state} {selectedDebtor.zipCode}
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Account Details */}
                    <div className="space-y-3">
                      <h4 className="font-medium">Account Details</h4>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <DollarSign className="w-4 h-4 text-muted-foreground" />
                          <span>Current Balance: {formatCurrency(selectedDebtor.currentBalance)}</span>
                        </div>
                        {selectedDebtor.originalAmount && (
                          <div className="flex items-center gap-2">
                            <DollarSign className="w-4 h-4 text-muted-foreground" />
                            <span>Original Amount: {formatCurrency(selectedDebtor.originalAmount)}</span>
                          </div>
                        )}
                        <div className="flex items-center gap-2">
                          <Badge className={getStatusColor(selectedDebtor.status)} variant="secondary">
                            {selectedDebtor.status}
                          </Badge>
                          <Badge className={getPriorityColor(selectedDebtor.priority)} variant="secondary">
                            {selectedDebtor.priority}
                          </Badge>
                        </div>
                        {selectedDebtor.source && (
                          <div className="text-sm text-muted-foreground">
                            Source: {selectedDebtor.source}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Contact History */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="w-5 h-5" />
                    Contact History
                  </CardTitle>
                  <CardDescription>
                    Previous contact attempts and outcomes
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {contactLogs && contactLogs.length > 0 ? (
                    <div className="space-y-4">
                      {contactLogs.map((log: ContactLog) => (
                        <div key={log.id} className="border rounded-lg p-4">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <Badge variant="outline">{log.contactMethod}</Badge>
                              <Badge 
                                className={
                                  log.outcome === "payment-received" || log.outcome === "contact-made"
                                    ? "bg-green-100 text-green-800"
                                    : log.outcome === "dispute"
                                    ? "bg-red-100 text-red-800"
                                    : "bg-gray-100 text-gray-800"
                                }
                                variant="secondary"
                              >
                                {log.outcome}
                              </Badge>
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {new Date(log.createdAt).toLocaleDateString()} {new Date(log.createdAt).toLocaleTimeString()}
                            </div>
                          </div>
                          <p className="text-sm mb-2">{log.notes}</p>
                          {log.duration && (
                            <div className="text-xs text-muted-foreground">
                              Duration: {log.duration} minutes
                            </div>
                          )}
                          {log.nextContactDate && (
                            <div className="text-xs text-muted-foreground">
                              Next contact: {new Date(log.nextContactDate).toLocaleDateString()}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      No contact history yet. Click "Log Contact" to record your first interaction.
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card className="h-96 flex items-center justify-center">
              <div className="text-center text-muted-foreground">
                <User className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Select an account from the list to view details and manage contacts</p>
              </div>
            </Card>
          )}
        </div>
      </div>

      {/* Contact Form Modal */}
      {showContactForm && selectedDebtor && (
        <ContactForm 
          debtor={selectedDebtor} 
          onClose={() => setShowContactForm(false)} 
        />
      )}
    </div>
  );
}