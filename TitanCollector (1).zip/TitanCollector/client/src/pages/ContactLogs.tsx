export default function ContactLogs() {
  return (
    <div className="min-h-screen bg-background p-6">
      <h1 className="text-2xl font-bold">Contact Logs</h1>
      <p className="text-muted-foreground">Coming soon...</p>
    </div>
  );
}