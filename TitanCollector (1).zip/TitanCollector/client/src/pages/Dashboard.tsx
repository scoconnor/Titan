import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { 
  Phone, 
  DollarSign, 
  Users, 
  AlertTriangle, 
  Plus,
  Search,
  Filter,
  Calendar,
  TrendingUp
} from "lucide-react";

interface Debtor {
  id: string;
  firstName: string;
  lastName: string;
  phone: string;
  currentBalance: string;
  status: string;
  priority: string;
  nextContactDate?: string;
}

interface DashboardStats {
  totalDebtors: number;
  totalOwed: string;
  needContact: number;
  collected: string;
}

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: debtors, isLoading: debtorsLoading } = useQuery<{ debtors: Debtor[] }>({
    queryKey: ["/api/debtors"],
  });

  const getPriorityClass = (priority: string) => {
    switch (priority) {
      case "high":
        return "border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-950";
      case "medium":
        return "border-yellow-200 bg-yellow-50 dark:border-yellow-800 dark:bg-yellow-950";
      case "low":
        return "border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-950";
      default:
        return "border-gray-200 bg-gray-50 dark:border-gray-800 dark:bg-gray-950";
    }
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      active: { label: "Active", variant: "default" as const },
      paid: { label: "Paid", variant: "secondary" as const },
      settled: { label: "Settled", variant: "secondary" as const },
      dispute: { label: "Dispute", variant: "destructive" as const },
      legal: { label: "Legal", variant: "destructive" as const },
    };

    const config = statusConfig[status as keyof typeof statusConfig] || { 
      label: status, 
      variant: "outline" as const 
    };

    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  if (statsLoading || debtorsLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-64 mb-6"></div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-6">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Titan Collection Dashboard</h1>
          <p className="text-muted-foreground">
            Welcome to your debt collection management system
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button size="sm" variant="outline">
            <Calendar className="w-4 h-4 mr-2" />
            Today
          </Button>
          <Button size="sm">
            <TrendingUp className="w-4 h-4 mr-2" />
            Reports
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Debtors</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalDebtors || 0}</div>
            <p className="text-xs text-muted-foreground">
              Active accounts in system
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Owed</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">${stats?.totalOwed || "0.00"}</div>
            <p className="text-xs text-muted-foreground">
              Outstanding debt amount
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Collected Today</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">${stats?.collected || "0.00"}</div>
            <p className="text-xs text-muted-foreground">
              +12% from yesterday
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Need Contact</CardTitle>
            <Phone className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{stats?.needContact || 0}</div>
            <p className="text-xs text-muted-foreground">
              Due for follow-up today
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">Quick Actions</h2>
        <div className="flex gap-2">
          <Button size="sm">
            <Plus className="w-4 h-4 mr-2" />
            Add Debtor
          </Button>
          <Button variant="outline" size="sm">
            <Search className="w-4 h-4 mr-2" />
            Search
          </Button>
          <Button variant="outline" size="sm">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
        </div>
      </div>

      {/* Recent Debtors / Priority List */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>High Priority Accounts</CardTitle>
            <CardDescription>
              Accounts requiring immediate attention
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {debtors?.debtors
                ?.filter((debtor: Debtor) => debtor.priority === "high")
                ?.slice(0, 5)
                ?.map((debtor: Debtor) => (
                  <div key={debtor.id} className={`flex items-center justify-between p-3 rounded-lg border ${getPriorityClass(debtor.priority)}`}>
                    <div>
                      <div className="font-medium">
                        {debtor.firstName} {debtor.lastName}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        ${debtor.currentBalance} • {debtor.phone}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusBadge(debtor.status)}
                      <Button size="sm" variant="outline">View</Button>
                    </div>
                  </div>
                ))}
              {(!debtors?.debtors || debtors.debtors.filter((d: Debtor) => d.priority === "high").length === 0) && (
                <div className="text-center py-4 text-muted-foreground">
                  No high priority accounts at this time
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Scheduled for Today</CardTitle>
            <CardDescription>
              Contacts due for follow-up
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {debtors?.debtors
                ?.filter((debtor: Debtor) => {
                  if (!debtor.nextContactDate) return false;
                  const contactDate = new Date(debtor.nextContactDate);
                  const today = new Date();
                  return contactDate.toDateString() === today.toDateString();
                })
                ?.slice(0, 5)
                ?.map((debtor: Debtor) => (
                  <div key={debtor.id} className="flex items-center justify-between p-3 rounded-lg border">
                    <div>
                      <div className="font-medium">
                        {debtor.firstName} {debtor.lastName}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        ${debtor.currentBalance} • {debtor.phone}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button size="sm" variant="outline">
                        <Phone className="w-4 h-4 mr-1" />
                        Call
                      </Button>
                      <Button size="sm" variant="outline">View</Button>
                    </div>
                  </div>
                ))}
              {(!debtors?.debtors || debtors.debtors.filter((d: Debtor) => d.nextContactDate).length === 0) && (
                <div className="text-center py-4 text-muted-foreground">
                  No contacts scheduled for today
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}