import { useParams } from "wouter";

export default function DebtorProfile() {
  const { id } = useParams<{ id: string }>();
  
  return (
    <div className="min-h-screen bg-background p-6">
      <h1 className="text-2xl font-bold">Debtor Profile: {id}</h1>
      <p className="text-muted-foreground">Coming soon...</p>
    </div>
  );
}