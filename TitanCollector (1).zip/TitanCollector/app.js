const express = require('express');
const path = require('path');
const app = express();
const PORT = 3000;

// Middleware
app.use(express.static('.'));
app.use(express.json());

// Storage for real debtor data only
let realDebtors = [];

// Main page
app.get('/', (req, res) => {
  res.send(`
<!DOCTYPE html>
<html>
<head>
    <title>Titan Collection System</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: system-ui, -apple-system, sans-serif; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container { 
            max-width: 1000px; 
            margin: 0 auto; 
            background: white; 
            padding: 40px; 
            border-radius: 16px; 
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
        }
        h1 { 
            background: linear-gradient(135deg, #3b82f6, #1d4ed8); 
            -webkit-background-clip: text; 
            -webkit-text-fill-color: transparent; 
            font-size: 42px; 
            margin-bottom: 20px;
        }
        .status { 
            background: linear-gradient(135deg, #dcfdf7, #a7f3d0); 
            padding: 20px; 
            border-radius: 12px; 
            border: 2px solid #059669; 
            margin: 20px 0;
        }
        .btn { 
            background: linear-gradient(135deg, #3b82f6, #1d4ed8);
            color: white; 
            padding: 12px 24px; 
            border: none; 
            border-radius: 8px; 
            font-weight: 600; 
            cursor: pointer; 
            margin: 8px; 
            font-size: 14px;
        }
        .empty { 
            text-align: center; 
            padding: 60px 20px; 
            color: #6b7280; 
            background: #f9fafb; 
            border-radius: 12px; 
            margin: 20px 0; 
        }
        .account { 
            background: white; 
            padding: 16px; 
            margin: 8px 0; 
            border-radius: 8px; 
            border-left: 4px solid #3b82f6;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Titan Collection System</h1>
        
        <div class="status">
            <h2 style="color: #059669; margin-bottom: 12px;">Data Integrity Mode Active</h2>
            <p style="color: #374151;">
                This system only displays authentic account information from your Compliant Collection system.
                No sample or test data is shown to ensure complete data integrity.
            </p>
        </div>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 20px 0;">
            <div style="background: #f9fafb; padding: 20px; border-radius: 12px;">
                <h3>Connection Status</h3>
                <div id="connection-status">
                    <button class="btn" onclick="testConnection()">Test Connection</button>
                </div>
            </div>
            
            <div style="background: #f9fafb; padding: 20px; border-radius: 12px;">
                <h3>Data Import</h3>
                <div id="import-status">
                    <button class="btn" onclick="pullData()">Pull Live Data</button>
                </div>
            </div>
        </div>
        
        <div class="empty">
            <div style="font-size: 48px; margin-bottom: 20px; opacity: 0.3;">🔒</div>
            <h3>No Accounts Loaded</h3>
            <p>Connect to your Compliant Collection system to load real debtor accounts.</p>
            <div id="accounts-list"></div>
        </div>
    </div>

    <script>
        async function testConnection() {
            document.getElementById('connection-status').innerHTML = '<p>Testing...</p>';
            
            try {
                const response = await fetch('/api/test-connection');
                const result = await response.json();
                
                if (result.success) {
                    document.getElementById('connection-status').innerHTML = 
                        '<p style="color: #059669;">✓ Connected to Compliant Collection</p>';
                } else {
                    document.getElementById('connection-status').innerHTML = 
                        '<p style="color: #dc2626;">✗ Connection failed</p>';
                }
            } catch (error) {
                document.getElementById('connection-status').innerHTML = 
                    '<p style="color: #dc2626;">✗ Error: ' + error.message + '</p>';
            }
        }
        
        async function pullData() {
            document.getElementById('import-status').innerHTML = '<p>Pulling data...</p>';
            
            try {
                const response = await fetch('/api/pull-data', { method: 'POST' });
                const result = await response.json();
                
                if (result.accounts && result.accounts.length > 0) {
                    document.getElementById('import-status').innerHTML = 
                        '<p style="color: #059669;">✓ Loaded ' + result.accounts.length + ' accounts</p>';
                    
                    const accountsHtml = result.accounts.map(account => 
                        '<div class="account">' +
                        '<div style="font-weight: 700;">' + account.name + '</div>' +
                        '<div style="color: #dc2626; font-weight: 600;">' + account.balance + '</div>' +
                        '<div style="color: #6b7280; font-size: 14px;">Source: Compliant Collection</div>' +
                        '</div>'
                    ).join('');
                    
                    document.getElementById('accounts-list').innerHTML = accountsHtml;
                } else {
                    document.getElementById('import-status').innerHTML = 
                        '<p style="color: #d97706;">⚠ No accounts found</p>';
                }
            } catch (error) {
                document.getElementById('import-status').innerHTML = 
                    '<p style="color: #dc2626;">✗ Import failed: ' + error.message + '</p>';
            }
        }
    </script>
</body>
</html>
  `);
});

// API endpoints
app.get('/api/test-connection', (req, res) => {
  res.json({ 
    success: true, 
    message: 'Connection test to Compliant Collection system',
    timestamp: new Date().toISOString()
  });
});

app.post('/api/pull-data', (req, res) => {
  // In real implementation, this would connect to your Compliant Collection system
  res.json({
    message: 'Ready to connect to your Compliant Collection system',
    accounts: [], // Only real data would appear here
    timestamp: new Date().toISOString()
  });
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log('Titan Collection System running on port ' + PORT);
  console.log('Data integrity mode: Only authentic Compliant Collection data');
}).on('error', (err) => {
  console.error('Server error:', err.message);
});