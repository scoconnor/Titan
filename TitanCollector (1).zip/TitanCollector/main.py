#!/usr/bin/env python3
import http.server
import socketserver
import json
import urllib.parse as urlparse

import os
PORT = int(os.environ.get('PORT', 3000))

class TitanHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse.urlparse(self.path)
        
        # API Health endpoint
        if parsed.path == '/api/health':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            response = {
                "status": "healthy",
                "timestamp": "2025-07-22T01:05:00.000Z",
                "message": "Titan Collection System API is running"
            }
            self.wfile.write(json.dumps(response).encode())
            return
            
        # API Debtors endpoint
        if parsed.path == '/api/debtors':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            debtors = {
                "debtors": [
                    {
                        "id": "1",
                        "firstName": "Michael",
                        "lastName": "Rodriguez",
                        "phone": "(609) 555-0123",
                        "email": "mrodriguez@email.com",
                        "currentBalance": "$8,737.42",
                        "originalAmount": "$9,500.00",
                        "priority": "high",
                        "status": "active",
                        "source": "Compliant Collection"
                    },
                    {
                        "id": "2",
                        "firstName": "Sarah",
                        "lastName": "Johnson", 
                        "phone": "(856) 555-0198",
                        "email": "sarah.j@email.com",
                        "currentBalance": "$3,245.18",
                        "originalAmount": "$4,200.00",
                        "priority": "medium",
                        "status": "active",
                        "source": "Compliant Collection"
                    },
                    {
                        "id": "3",
                        "firstName": "David",
                        "lastName": "Thompson",
                        "phone": "(732) 555-0167",
                        "currentBalance": "$1,892.33", 
                        "originalAmount": "$2,800.00",
                        "priority": "low",
                        "status": "dispute",
                        "source": "Compliant Collection"
                    }
                ]
            }
            self.wfile.write(json.dumps(debtors).encode())
            return
        
        # Serve index.html for all other requests
        if parsed.path == '/' or not parsed.path.startswith('/api'):
            self.path = '/index.html'
            
        return super().do_GET()

print("🚀 Starting Titan Collection System on port", PORT)
print("🎨 Agent Workspace will be available at http://localhost:" + str(PORT))
print("📊 API endpoints: /api/health and /api/debtors")

with socketserver.TCPServer(("0.0.0.0", PORT), TitanHandler) as httpd:
    print("✅ Titan Collection System server running successfully!")
    print("Preview should now be visible in Replit")
    httpd.serve_forever()