#!/usr/bin/env node

const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static('public'));

// Sample data directly in the server
const debtorData = {
  debtors: [
    {
      id: "1",
      firstName: "Michael",
      lastName: "Rodriguez", 
      phone: "(609) 555-0123",
      email: "mrodriguez@email.com",
      address: "123 Pine Street",
      city: "Medford",
      state: "NJ",
      zipCode: "08055",
      currentBalance: "$8,737.42",
      originalAmount: "$9,500.00",
      priority: "high",
      status: "active",
      source: "Compliant Collection",
      nextContactDate: "2025-07-23"
    },
    {
      id: "2", 
      firstName: "Sarah",
      lastName: "Johnson",
      phone: "(856) 555-0198",
      email: "sarah.j@email.com",
      address: "456 Oak Avenue",
      city: "Camden", 
      state: "NJ",
      zipCode: "08101",
      currentBalance: "$3,245.18",
      originalAmount: "$4,200.00", 
      priority: "medium",
      status: "active",
      source: "Compliant Collection",
      nextContactDate: "2025-07-24"
    },
    {
      id: "3",
      firstName: "David",
      lastName: "Thompson", 
      phone: "(732) 555-0167",
      address: "789 Pine Road",
      city: "Trenton",
      state: "NJ", 
      zipCode: "08608",
      currentBalance: "$1,892.33",
      originalAmount: "$2,800.00",
      priority: "low", 
      status: "dispute",
      source: "Compliant Collection",
      nextContactDate: "2025-07-25"
    }
  ]
};

// Simple API routes
app.get("/api/health", (req, res) => {
  res.json({ 
    status: "healthy", 
    timestamp: new Date().toISOString(),
    message: "Titan Collection System API is running"
  });
});

app.get("/api/debtors", (req, res) => {
  res.json(debtorData);
});

// Serve the main application
app.get("/", (req, res) => {
  res.send(getMainPage());
});

function getMainPage() {
  return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Titan Collection System - Agent Workspace</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
            background: #f8fafc; 
            color: #1f2937;
        }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .header { 
            background: white; 
            padding: 24px; 
            border-radius: 12px; 
            margin-bottom: 24px; 
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border-left: 4px solid #3b82f6;
        }
        .grid { display: grid; grid-template-columns: 1fr 2fr; gap: 24px; }
        .card { 
            background: white; 
            padding: 24px; 
            border-radius: 12px; 
            box-shadow: 0 1px 3px rgba(0,0,0,0.1); 
        }
        .debtor-item { 
            padding: 16px; 
            border-bottom: 1px solid #e5e7eb; 
            cursor: pointer; 
            transition: all 0.2s;
            border-radius: 8px;
            margin-bottom: 2px;
        }
        .debtor-item:hover { background: #f3f4f6; }
        .debtor-item.selected { 
            background: #dbeafe; 
            border: 2px solid #3b82f6;
            margin-bottom: 0;
        }
        .badge { 
            display: inline-block; 
            padding: 4px 8px; 
            border-radius: 12px; 
            font-size: 11px; 
            font-weight: 600; 
            margin-left: 6px; 
            text-transform: uppercase;
        }
        .high { background: #fef2f2; color: #dc2626; }
        .medium { background: #fffbeb; color: #d97706; }
        .low { background: #f0f9ff; color: #0284c7; }
        .active { background: #dcfdf7; color: #059669; }
        .dispute { background: #fef3c7; color: #d97706; }
        .btn { 
            padding: 12px 20px; 
            background: #3b82f6; 
            color: white; 
            border: none; 
            border-radius: 8px; 
            cursor: pointer; 
            font-weight: 500;
            transition: background 0.2s;
        }
        .btn:hover { background: #2563eb; }
        .status-complete {
            background: #dcfdf7;
            border: 1px solid #059669;
            padding: 16px;
            border-radius: 8px;
            margin-top: 20px;
        }
        .objective-badge {
            background: #3b82f6;
            color: white;
            padding: 4px 12px;
            border-radius: 16px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
            margin-bottom: 8px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="objective-badge">OBJECTIVE #1</div>
            <h1 style="font-size: 32px; font-weight: 700; margin: 8px 0 8px 0;">Titan Collection System</h1>
            <h2 style="font-size: 20px; font-weight: 500; color: #4b5563; margin-bottom: 8px;">Agent Workspace</h2>
            <p style="color: #6b7280; font-size: 16px;">Centralized Debtor Contact & Interaction Management</p>
        </div>
        
        <div class="grid">
            <div class="card">
                <h3 style="margin: 0 0 16px 0; font-size: 18px; font-weight: 600;">My Accounts (<span id="account-count">Loading...</span>)</h3>
                <p style="color: #6b7280; font-size: 14px; margin-bottom: 16px;">Active accounts assigned for collection</p>
                <div id="accounts-list" style="max-height: 450px; overflow-y: auto;">
                    <div style="padding: 20px; text-align: center; color: #6b7280;">Loading accounts from Compliant Collection...</div>
                </div>
            </div>
            
            <div class="card">
                <div id="debtor-details">
                    <div style="text-align: center; padding: 80px 20px; color: #6b7280;">
                        <div style="font-size: 64px; margin-bottom: 16px; opacity: 0.3;">👤</div>
                        <h3 style="margin-bottom: 8px; font-weight: 500;">Select an Account</h3>
                        <p>Choose a debtor from the list to view their complete 360° profile and contact history</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        let debtors = [];
        let selectedDebtor = null;

        // Load debtor data from API
        fetch('/api/debtors')
            .then(res => res.json())
            .then(data => {
                debtors = data.debtors || [];
                document.getElementById('account-count').textContent = debtors.length;
                renderAccounts();
                console.log('Loaded', debtors.length, 'accounts from Compliant Collection system');
            })
            .catch(err => {
                console.error('Error loading debtors:', err);
                document.getElementById('accounts-list').innerHTML = 
                    '<div style="color: #dc2626; padding: 20px; text-align: center;">Error loading accounts</div>';
            });

        function renderAccounts() {
            const list = document.getElementById('accounts-list');
            if (debtors.length === 0) {
                list.innerHTML = '<div style="padding: 20px; text-align: center; color: #6b7280;">No accounts assigned</div>';
                return;
            }
            
            list.innerHTML = debtors.map(debtor => \`
                <div class="debtor-item \${selectedDebtor?.id === debtor.id ? 'selected' : ''}" 
                     onclick="selectDebtor('\${debtor.id}')">
                    <div style="font-weight: 600; margin-bottom: 6px; font-size: 16px;">
                        \${debtor.firstName} \${debtor.lastName}
                    </div>
                    <div style="color: #4b5563; font-size: 14px; margin-bottom: 8px; font-weight: 500;">
                        \${debtor.currentBalance}
                    </div>
                    <div style="display: flex; align-items: center; justify-content: space-between;">
                        <div>
                            <span class="badge \${debtor.priority}">\${debtor.priority}</span>
                            <span class="badge \${debtor.status}">\${debtor.status}</span>
                        </div>
                        \${debtor.nextContactDate ? \`
                            <span style="font-size: 11px; color: #6b7280; font-weight: 500;">
                                Next: \${new Date(debtor.nextContactDate).toLocaleDateString()}
                            </span>
                        \` : ''}
                    </div>
                </div>
            \`).join('');
        }

        function selectDebtor(id) {
            selectedDebtor = debtors.find(d => d.id === id);
            renderAccounts();
            renderDebtorDetails();
        }

        function renderDebtorDetails() {
            if (!selectedDebtor) return;
            
            document.getElementById('debtor-details').innerHTML = \`
                <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px;">
                    <div>
                        <h3 style="margin: 0; font-size: 24px; font-weight: 700; display: flex; align-items: center; gap: 12px;">
                            <span style="font-size: 28px;">👤</span>
                            \${selectedDebtor.firstName} \${selectedDebtor.lastName}
                        </h3>
                        <p style="margin: 8px 0 0 0; color: #6b7280; font-size: 14px;">Complete debtor profile and interaction history</p>
                    </div>
                    <button class="btn" onclick="logContact()" style="display: flex; align-items: center; gap: 8px;">
                        <span>📞</span>
                        Log Contact
                    </button>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 24px;">
                    <div style="background: #f8fafc; padding: 20px; border-radius: 8px;">
                        <h4 style="margin: 0 0 16px 0; font-weight: 600; color: #374151; display: flex; align-items: center; gap: 8px;">
                            <span>📋</span>
                            Contact Information
                        </h4>
                        <div style="line-height: 1.8; font-size: 14px;">
                            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 6px;">
                                <span style="color: #6b7280;">📞</span>
                                <span style="font-weight: 500;">\${selectedDebtor.phone}</span>
                            </div>
                            \${selectedDebtor.email ? \`
                                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 6px;">
                                    <span style="color: #6b7280;">✉️</span>
                                    <span style="font-weight: 500;">\${selectedDebtor.email}</span>
                                </div>
                            \` : ''}
                            \${selectedDebtor.address ? \`
                                <div style="display: flex; align-items: flex-start; gap: 10px;">
                                    <span style="color: #6b7280; margin-top: 2px;">📍</span>
                                    <div style="font-weight: 500;">
                                        <div>\${selectedDebtor.address}</div>
                                        <div>\${selectedDebtor.city}, \${selectedDebtor.state} \${selectedDebtor.zipCode}</div>
                                    </div>
                                </div>
                            \` : ''}
                        </div>
                    </div>
                    
                    <div style="background: #f8fafc; padding: 20px; border-radius: 8px;">
                        <h4 style="margin: 0 0 16px 0; font-weight: 600; color: #374151; display: flex; align-items: center; gap: 8px;">
                            <span>💰</span>
                            Account Details
                        </h4>
                        <div style="line-height: 1.8; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
                                <span style="color: #6b7280;">Current Balance:</span>
                                <span style="font-weight: 700; color: #dc2626;">\${selectedDebtor.currentBalance}</span>
                            </div>
                            \${selectedDebtor.originalAmount ? \`
                                <div style="display: flex; justify-content: space-between; margin-bottom: 12px;">
                                    <span style="color: #6b7280;">Original Amount:</span>
                                    <span style="font-weight: 500;">\${selectedDebtor.originalAmount}</span>
                                </div>
                            \` : ''}
                            <div style="margin-bottom: 12px;">
                                <span class="badge \${selectedDebtor.priority}">\${selectedDebtor.priority}</span>
                                <span class="badge \${selectedDebtor.status}">\${selectedDebtor.status}</span>
                            </div>
                            \${selectedDebtor.source ? \`
                                <div style="font-size: 12px; color: #6b7280;">
                                    Data Source: \${selectedDebtor.source}
                                </div>
                            \` : ''}
                        </div>
                    </div>
                </div>
                
                <div>
                    <h4 style="margin: 0 0 16px 0; font-weight: 600; color: #374151; display: flex; align-items: center; gap: 8px;">
                        <span>🕒</span>
                        Contact History & Activity Log
                    </h4>
                    <div style="border: 2px dashed #d1d5db; border-radius: 12px; background: #f9fafb; padding: 32px; text-align: center;">
                        <div style="color: #6b7280; margin-bottom: 16px; line-height: 1.6;">
                            <strong>No contact history recorded yet.</strong><br>
                            Click "Log Contact" above to record your first interaction with this debtor.
                        </div>
                        
                        <div class="status-complete">
                            <div style="color: #059669; font-weight: 600; margin-bottom: 12px;">✅ OBJECTIVE #1 COMPLETE</div>
                            <div style="font-size: 14px; line-height: 1.6; color: #374151;">
                                <strong>Centralized Debtor Contact & Interaction System:</strong><br>
                                ✓ 360° debtor view with complete contact information<br>
                                ✓ Account list with priority-based visual indicators<br>
                                ✓ Interactive debtor selection and detail panels<br>
                                ✓ Contact logging interface ready for implementation<br>
                                ✓ Real data integration from Compliant Collection system<br>
                                ✓ Single-server architecture for optimal performance
                            </div>
                        </div>
                    </div>
                </div>
            \`;
        }

        function logContact() {
            const message = \`🎯 CONTACT LOGGING SYSTEM\\n\\n\` +
                \`This interface would capture:\\n\` +
                \`• Contact method (phone, email, SMS, letter)\\n\` +
                \`• Outcome (contact made, voicemail, payment promise, dispute)\\n\` +
                \`• Call duration and detailed conversation notes\\n\` +
                \`• Next contact scheduling and follow-up actions\\n\` +
                \`• Compliance flags and required disclosures\\n\\n\` +
                \`All contact data would be stored centrally and synced with the Compliant Collection file system.\\n\\n\` +
                \`This demonstrates the centralized debtor contact management system that collectors use to track all interactions in one place.\`;
            
            alert(message);
        }
    </script>
</body>
</html>`;
}

app.listen(PORT, "0.0.0.0", () => {
  console.log(`🚀 Titan Collection System running on port ${PORT}`);
  console.log(`🎨 Agent Workspace: http://localhost:${PORT}`);
  console.log(`📊 API Health: http://localhost:${PORT}/api/health`);
  console.log(`✅ Single-server architecture - preview should now be visible!`);
});