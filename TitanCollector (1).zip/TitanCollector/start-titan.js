// Simple Titan server with live integration
const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());
app.use(express.static('.'));

// Storage for real debtor data
let liveDebtors = [];

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    message: 'Titan Collection System API - Live Integration'
  });
});

// Get only real debtors from Compliant Collection
app.get('/api/debtors', (req, res) => {
  const compliantDebtors = liveDebtors.filter(debtor => 
    debtor.source === 'compliant-collection'
  );
  res.json({ debtors: compliantDebtors });
});

// Test connection to Compliant Collection
app.get('/api/integration/check-connection', async (req, res) => {
  try {
    const compliantUrl = 'https://www.compliantcollection.com';
    
    const response = await fetch(compliantUrl, {
      method: 'HEAD',
      headers: {
        'User-Agent': 'Titan-Collection-System/1.0'
      }
    });

    res.json({
      status: response.ok ? 'connected' : 'unreachable',
      statusCode: response.status,
      url: compliantUrl,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    res.json({
      status: 'error',
      error: error.message,
      url: 'https://www.compliantcollection.com',
      timestamp: new Date().toISOString()
    });
  }
});

// Pull live data from Compliant Collection
app.post('/api/integration/pull-debtors', async (req, res) => {
  try {
    console.log('Pulling debtors from Compliant Collection...');
    
    const compliantUrl = 'https://www.compliantcollection.com';
    const testEndpoints = [
      '/api/borrowers',
      '/api/debtors', 
      '/api/accounts',
      '/api/files',
      '/api/clients',
      '/api/data'
    ];
    
    let workingEndpoint = null;
    let debtorData = null;
    
    for (const endpoint of testEndpoints) {
      try {
        console.log(`Testing: ${compliantUrl}${endpoint}`);
        const response = await fetch(`${compliantUrl}${endpoint}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'User-Agent': 'Titan-Collection-System/1.0'
          }
        });
        
        if (response.ok) {
          const contentType = response.headers.get('content-type');
          if (contentType && contentType.includes('application/json')) {
            debtorData = await response.json();
            workingEndpoint = endpoint;
            console.log(`Success: ${endpoint}`);
            break;
          }
        }
      } catch (error) {
        console.log(`${endpoint}: ${error.message}`);
      }
    }

    if (!debtorData || !workingEndpoint) {
      return res.status(502).json({
        message: 'Could not find API endpoints returning JSON data',
        details: `Tested: ${testEndpoints.join(', ')}`,
        suggestion: 'Verify your system has API endpoints that return JSON'
      });
    }

    // Process the data
    let dataArray = [];
    if (Array.isArray(debtorData)) {
      dataArray = debtorData;
    } else if (debtorData.borrowers) {
      dataArray = debtorData.borrowers;
    } else if (debtorData.debtors) {
      dataArray = debtorData.debtors;
    } else if (debtorData.files) {
      dataArray = debtorData.files;
    } else if (debtorData.data) {
      dataArray = debtorData.data;
    }

    console.log(`Processing ${dataArray.length} records`);

    // Convert to Titan format
    const convertedDebtors = dataArray.map((item, index) => ({
      id: `cc-${item.id || index}`,
      externalId: item.id || `ext-${index}`,
      firstName: item.firstName || item.clientName?.split(' ')[0] || 'Unknown',
      lastName: item.lastName || item.clientName?.split(' ').slice(1).join(' ') || 'Unknown',
      phone: item.phone || item.phoneNumber || '',
      email: item.email || item.emailAddress || '',
      currentBalance: item.currentBalance || item.balance || item.amount || '0.00',
      originalAmount: item.originalAmount || item.originalBalance || item.currentBalance || '0.00',
      status: item.status === 'dispute' ? 'dispute' : 'active',
      priority: item.priority || 'medium',
      source: 'compliant-collection',
      assignedCollectorId: item.assignedTo || 'current-agent',
      address: item.address || '',
      city: item.city || '',
      state: item.state || '',
      zipCode: item.zipCode || item.zip || ''
    }));

    // Store the real data
    liveDebtors = convertedDebtors;

    res.json({
      message: `Successfully pulled ${convertedDebtors.length} debtors from Compliant Collection`,
      debtors: convertedDebtors,
      workingEndpoint: workingEndpoint,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Error pulling debtors:', error);
    res.status(500).json({
      message: 'Failed to pull debtors from Compliant Collection',
      error: error.message
    });
  }
});

// Serve the live integration page as the main interface
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'titan-live.html'));
});

// Also serve the cleaned demo page (with no sample data)
app.get('/demo', (req, res) => {
  res.sendFile(path.join(__dirname, 'titan-demo.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log('Titan Collection System running on port ' + PORT);
  console.log('Live integration with Compliant Collection ready');
  console.log('Access at http://localhost:' + PORT);
  console.log('Data integrity: Only authentic Compliant Collection accounts loaded');
}).on('error', (err) => {
  console.error('Server startup error:', err.message);
});