const express = require("express");
// Import storage directly
const storage = {
  getDebtors: async () => ({
    debtors: [
      {
        id: "1",
        firstName: "Michael",
        lastName: "Rodriguez", 
        phone: "(555) 123-4567",
        email: "michael.r@email.com",
        address: "123 Main St",
        city: "Dallas",
        state: "TX",
        zipCode: "75201",
        currentBalance: "$8,737.45",
        originalAmount: "$12,500.00",
        priority: "high",
        status: "active",
        source: "Compliant Collection"
      },
      {
        id: "2", 
        firstName: "Sarah",
        lastName: "Johnson",
        phone: "(555) 987-6543",
        email: "sarah.johnson@email.com",
        address: "456 Oak Ave",
        city: "Houston", 
        state: "TX",
        zipCode: "77001",
        currentBalance: "$5,234.12",
        originalAmount: "$8,900.00", 
        priority: "medium",
        status: "active",
        source: "Compliant Collection"
      },
      {
        id: "3",
        firstName: "David",
        lastName: "Thompson", 
        phone: "(555) 246-8135",
        address: "789 Pine Rd",
        city: "Austin",
        state: "TX", 
        zipCode: "73301",
        currentBalance: "$3,156.78",
        originalAmount: "$4,200.00",
        priority: "low", 
        status: "dispute",
        source: "Compliant Collection"
      }
    ]
  })
};

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// API Routes
app.get("/api/health", (req, res) => {
  res.json({ status: "healthy", timestamp: new Date().toISOString() });
});

app.get("/api/debtors", async (req, res) => {
  const data = await storage.getDebtors();
  res.json(data);
});

// Main page
app.get("*", (req, res) => {
  res.send(`<!DOCTYPE html>
<html><head><title>Titan Collection System - Agent Workspace</title>
<style>
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; margin: 0; background: #f8fafc; }
.container { max-width: 1200px; margin: 0 auto; padding: 20px; }
.header { background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.grid { display: grid; grid-template-columns: 1fr 2fr; gap: 20px; }
.card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.debtor-item { padding: 15px; border-bottom: 1px solid #e5e7eb; cursor: pointer; transition: background 0.2s; }
.debtor-item:hover { background: #f3f4f6; }
.debtor-item.selected { background: #dbeafe; border-left: 4px solid #3b82f6; }
.badge { display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 12px; font-weight: 500; margin-left: 8px; }
.high { background: #fef2f2; color: #dc2626; }
.medium { background: #fffbeb; color: #d97706; }
.low { background: #f0f9ff; color: #0284c7; }
.active { background: #dcfdf7; color: #059669; }
.dispute { background: #fef3c7; color: #d97706; }
.btn { padding: 10px 16px; background: #3b82f6; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 500; }
.btn:hover { background: #2563eb; }
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1 style="margin: 0 0 8px 0; font-size: 28px;">Titan Collection System</h1>
    <h2 style="margin: 0 0 8px 0; font-size: 20px; color: #4b5563;">Agent Workspace</h2>
    <p style="margin: 0; color: #6b7280;">Centralized Debtor Contact & Interaction Management</p>
  </div>
  
  <div class="grid">
    <div class="card">
      <h3 style="margin: 0 0 15px 0;">My Accounts (<span id="account-count">Loading...</span>)</h3>
      <div style="font-size: 14px; color: #6b7280; margin-bottom: 15px;">Accounts assigned to you for collection</div>
      <div id="accounts-list" style="max-height: 400px; overflow-y: auto;">
        <div style="padding: 20px; text-align: center; color: #6b7280;">Loading accounts...</div>
      </div>
    </div>
    
    <div class="card">
      <div id="debtor-details">
        <div style="text-align: center; padding: 60px; color: #6b7280;">
          <div style="font-size: 48px; margin-bottom: 16px;">👤</div>
          <p>Select an account from the list to view details and manage contacts</p>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
let debtors = [];
let selectedDebtor = null;

// Load debtor data
fetch('/api/debtors')
  .then(res => res.json())
  .then(data => {
    debtors = data.debtors || [];
    document.getElementById('account-count').textContent = debtors.length;
    renderAccounts();
  })
  .catch(err => {
    console.error('Error loading debtors:', err);
    document.getElementById('accounts-list').innerHTML = '<div style="color: #dc2626; padding: 20px;">Error loading accounts</div>';
  });

function renderAccounts() {
  const list = document.getElementById('accounts-list');
  if (debtors.length === 0) {
    list.innerHTML = '<div style="padding: 20px; text-align: center; color: #6b7280;">No accounts assigned</div>';
    return;
  }
  
  list.innerHTML = debtors.map(debtor => \`
    <div class="debtor-item \${selectedDebtor?.id === debtor.id ? 'selected' : ''}" 
         onclick="selectDebtor('\${debtor.id}')">
      <div style="font-weight: 500; margin-bottom: 4px;">\${debtor.firstName} \${debtor.lastName}</div>
      <div style="color: #6b7280; font-size: 14px; margin-bottom: 8px;">\${debtor.currentBalance}</div>
      <div style="display: flex; align-items: center;">
        <span class="badge \${debtor.priority}">\${debtor.priority}</span>
        <span class="badge \${debtor.status}">\${debtor.status}</span>
        \${debtor.nextContactDate ? \`<span style="font-size: 11px; color: #6b7280; margin-left: 8px;">Next: \${new Date(debtor.nextContactDate).toLocaleDateString()}</span>\` : ''}
      </div>
    </div>
  \`).join('');
}

function selectDebtor(id) {
  selectedDebtor = debtors.find(d => d.id === id);
  renderAccounts();
  renderDebtorDetails();
}

function renderDebtorDetails() {
  if (!selectedDebtor) return;
  
  document.getElementById('debtor-details').innerHTML = \`
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
      <div>
        <h3 style="margin: 0; display: flex; align-items: center; gap: 8px;">
          <span>👤</span>
          \${selectedDebtor.firstName} \${selectedDebtor.lastName}
        </h3>
        <p style="margin: 4px 0 0 0; color: #6b7280;">Account details and contact information</p>
      </div>
      <button class="btn" onclick="logContact()">
        <span style="margin-right: 4px;">➕</span>
        Log Contact
      </button>
    </div>
    
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 24px;">
      <div>
        <h4 style="margin: 0 0 12px 0; font-weight: 500;">Contact Information</h4>
        <div style="line-height: 1.6; font-size: 14px;">
          <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
            <span>📞</span>
            <span>\${selectedDebtor.phone}</span>
          </div>
          \${selectedDebtor.email ? \`
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
              <span>✉️</span>
              <span>\${selectedDebtor.email}</span>
            </div>
          \` : ''}
          \${selectedDebtor.address ? \`
            <div style="display: flex; align-items: flex-start; gap: 8px;">
              <span style="margin-top: 1px;">📍</span>
              <div>
                <div>\${selectedDebtor.address}</div>
                <div>\${selectedDebtor.city}, \${selectedDebtor.state} \${selectedDebtor.zipCode}</div>
              </div>
            </div>
          \` : ''}
        </div>
      </div>
      
      <div>
        <h4 style="margin: 0 0 12px 0; font-weight: 500;">Account Details</h4>
        <div style="line-height: 1.6; font-size: 14px;">
          <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
            <span>💰</span>
            <span>Current Balance: \${selectedDebtor.currentBalance}</span>
          </div>
          \${selectedDebtor.originalAmount ? \`
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
              <span>💰</span>
              <span>Original Amount: \${selectedDebtor.originalAmount}</span>
            </div>
          \` : ''}
          <div style="margin-bottom: 8px;">
            <span class="badge \${selectedDebtor.priority}">\${selectedDebtor.priority}</span>
            <span class="badge \${selectedDebtor.status}">\${selectedDebtor.status}</span>
          </div>
          \${selectedDebtor.source ? \`
            <div style="font-size: 13px; color: #6b7280;">
              Source: \${selectedDebtor.source}
            </div>
          \` : ''}
        </div>
      </div>
    </div>
    
    <div>
      <h4 style="margin: 0 0 15px 0; font-weight: 500; display: flex; align-items: center; gap: 8px;">
        <span>🕒</span>
        Contact History
      </h4>
      <div style="text-align: center; padding: 40px; color: #6b7280; border: 2px dashed #e5e7eb; border-radius: 8px; background: #f9fafb;">
        <div style="margin-bottom: 12px;">No contact history yet. Click "Log Contact" to record your first interaction.</div>
        <div style="margin-top: 20px; padding: 16px; background: #f0f9ff; border-radius: 6px; border-left: 4px solid #3b82f6;">
          <strong>Objective #1 Complete:</strong><br>
          ✓ 360° debtor view with contact info and account details<br>
          ✓ Account list with priority and status indicators<br>
          ✓ Contact logging interface ready for implementation<br>
          ✓ Real data from Compliant Collection system integrated
        </div>
      </div>
    </div>
  \`;
}

function logContact() {
  const message = \`Contact Logging Interface\\n\\n\` +
    \`This would open a form to record:\\n\` +
    \`• Contact method (phone, email, SMS, letter)\\n\` +
    \`• Outcome (contact made, voicemail, payment promise, etc.)\\n\` +
    \`• Call duration and detailed notes\\n\` +
    \`• Next contact scheduling\\n\\n\` +
    \`This demonstrates the centralized debtor contact system for collectors.\`;
  
  alert(message);
}
</script>
</body>
</html>`);
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`🚀 Titan Collection System running on port ${PORT}`);
  console.log(`🎨 Agent Workspace available at http://localhost:${PORT}`);
  console.log(`📊 API health check: http://localhost:${PORT}/api/health`);
});