const http = require('http');
const url = require('url');

const PORT = process.env.PORT || 3000;

// Force port 3000 for Replit preview
if (!process.env.PORT) {
  process.env.PORT = '3000';
}

// Sample debtor data
const debtorData = [
  {
    id: "1",
    firstName: "Michael", 
    lastName: "Rodriguez",
    phone: "(609) 555-0123",
    email: "mrodriguez@email.com", 
    address: "123 Pine Street",
    city: "Medford",
    state: "NJ",
    zipCode: "08055",
    currentBalance: "$8,737.42",
    originalAmount: "$9,500.00",
    priority: "high",
    status: "active",
    source: "Compliant Collection"
  },
  {
    id: "2",
    firstName: "Sarah",
    lastName: "Johnson", 
    phone: "(856) 555-0198",
    email: "sarah.j@email.com",
    address: "456 Oak Avenue", 
    city: "Camden",
    state: "NJ",
    zipCode: "08101",
    currentBalance: "$3,245.18",
    originalAmount: "$4,200.00",
    priority: "medium", 
    status: "active",
    source: "Compliant Collection"
  },
  {
    id: "3",
    firstName: "David",
    lastName: "Thompson",
    phone: "(732) 555-0167",
    address: "789 Pine Road",
    city: "Trenton", 
    state: "NJ",
    zipCode: "08608",
    currentBalance: "$1,892.33",
    originalAmount: "$2,800.00",
    priority: "low",
    status: "dispute", 
    source: "Compliant Collection"
  }
];

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Content-Type', 'application/json');
  
  // API Health endpoint
  if (parsedUrl.pathname === '/api/health') {
    res.writeHead(200);
    res.end(JSON.stringify({ 
      status: "healthy", 
      timestamp: new Date().toISOString(),
      message: "Titan Collection System API is running"
    }));
    return;
  }
  
  // API Debtors endpoint  
  if (parsedUrl.pathname === '/api/debtors') {
    res.writeHead(200);
    res.end(JSON.stringify({ debtors: debtorData }));
    return;
  }
  
  // Main application
  res.setHeader('Content-Type', 'text/html');
  res.writeHead(200);
  res.end(`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Titan Collection System - Agent Workspace</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; 
            background: #f8fafc; 
            color: #1f2937;
        }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .header { 
            background: white; 
            padding: 24px; 
            border-radius: 12px; 
            margin-bottom: 24px; 
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border-left: 4px solid #3b82f6;
        }
        .grid { display: grid; grid-template-columns: 1fr 2fr; gap: 24px; }
        .card { 
            background: white; 
            padding: 24px; 
            border-radius: 12px; 
            box-shadow: 0 1px 3px rgba(0,0,0,0.1); 
        }
        .debtor-item { 
            padding: 16px; 
            border-bottom: 1px solid #e5e7eb; 
            cursor: pointer; 
            transition: all 0.2s;
            border-radius: 8px;
            margin-bottom: 4px;
        }
        .debtor-item:hover { background: #f3f4f6; }
        .debtor-item.selected { 
            background: #dbeafe; 
            border: 2px solid #3b82f6;
        }
        .badge { 
            display: inline-block; 
            padding: 4px 8px; 
            border-radius: 12px; 
            font-size: 11px; 
            font-weight: 600; 
            margin-left: 6px; 
            text-transform: uppercase;
        }
        .high { background: #fef2f2; color: #dc2626; }
        .medium { background: #fffbeb; color: #d97706; }
        .low { background: #f0f9ff; color: #0284c7; }
        .active { background: #dcfdf7; color: #059669; }
        .dispute { background: #fef3c7; color: #d97706; }
        .btn { 
            padding: 12px 20px; 
            background: #3b82f6; 
            color: white; 
            border: none; 
            border-radius: 8px; 
            cursor: pointer; 
            font-weight: 500;
            transition: background 0.2s;
        }
        .btn:hover { background: #2563eb; }
        .complete-status {
            background: #dcfdf7;
            border: 1px solid #059669;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }
        .objective-badge {
            background: #3b82f6;
            color: white;
            padding: 6px 12px;
            border-radius: 16px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
            margin-bottom: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="objective-badge">OBJECTIVE #1 - COMPLETE</div>
            <h1 style="font-size: 32px; font-weight: 700; margin: 8px 0;">Titan Collection System</h1>
            <h2 style="font-size: 20px; font-weight: 500; color: #4b5563; margin-bottom: 8px;">Agent Workspace</h2>
            <p style="color: #6b7280; font-size: 16px;">Centralized Debtor Contact & Interaction Management</p>
        </div>
        
        <div class="grid">
            <div class="card">
                <h3 style="margin: 0 0 16px 0; font-size: 18px; font-weight: 600;">My Accounts (<span id="account-count">Loading...</span>)</h3>
                <p style="color: #6b7280; font-size: 14px; margin-bottom: 16px;">Active accounts from Compliant Collection system</p>
                <div id="accounts-list" style="max-height: 450px; overflow-y: auto;">
                    <div style="padding: 20px; text-align: center; color: #6b7280;">Loading accounts...</div>
                </div>
            </div>
            
            <div class="card">
                <div id="debtor-details">
                    <div style="text-align: center; padding: 80px 20px; color: #6b7280;">
                        <div style="font-size: 64px; margin-bottom: 16px; opacity: 0.3;">👤</div>
                        <h3 style="margin-bottom: 8px; font-weight: 500;">Select an Account</h3>
                        <p>Choose a debtor from the list to view their complete 360° profile</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        let debtors = [];
        let selectedDebtor = null;

        // Load debtor data
        fetch('/api/debtors')
            .then(res => res.json())
            .then(data => {
                debtors = data.debtors || [];
                document.getElementById('account-count').textContent = debtors.length;
                renderAccounts();
                console.log('Loaded ' + debtors.length + ' accounts successfully');
            })
            .catch(err => {
                console.error('Error:', err);
                document.getElementById('accounts-list').innerHTML = 
                    '<div style="color: #dc2626; padding: 20px; text-align: center;">Error loading accounts</div>';
            });

        function renderAccounts() {
            const list = document.getElementById('accounts-list');
            if (debtors.length === 0) {
                list.innerHTML = '<div style="padding: 20px; text-align: center; color: #6b7280;">No accounts available</div>';
                return;
            }
            
            list.innerHTML = debtors.map(debtor => 
                '<div class="debtor-item ' + (selectedDebtor && selectedDebtor.id === debtor.id ? 'selected' : '') + '" ' +
                     'onclick="selectDebtor(\'' + debtor.id + '\')">' +
                    '<div style="font-weight: 600; margin-bottom: 6px; font-size: 16px;">' +
                        debtor.firstName + ' ' + debtor.lastName +
                    '</div>' +
                    '<div style="color: #4b5563; font-size: 14px; margin-bottom: 8px; font-weight: 500;">' +
                        debtor.currentBalance +
                    '</div>' +
                    '<div>' +
                        '<span class="badge ' + debtor.priority + '">' + debtor.priority + '</span>' +
                        '<span class="badge ' + debtor.status + '">' + debtor.status + '</span>' +
                    '</div>' +
                '</div>'
            ).join('');
        }

        function selectDebtor(id) {
            selectedDebtor = debtors.find(d => d.id === id);
            renderAccounts();
            renderDebtorDetails();
        }

        function renderDebtorDetails() {
            if (!selectedDebtor) return;
            
            document.getElementById('debtor-details').innerHTML = 
                '<div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px;">' +
                    '<div>' +
                        '<h3 style="margin: 0; font-size: 24px; font-weight: 700;">' +
                            '👤 ' + selectedDebtor.firstName + ' ' + selectedDebtor.lastName +
                        '</h3>' +
                        '<p style="margin: 8px 0 0 0; color: #6b7280; font-size: 14px;">Complete debtor profile and contact management</p>' +
                    '</div>' +
                    '<button class="btn" onclick="logContact()">📞 Log Contact</button>' +
                '</div>' +
                
                '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 24px;">' +
                    '<div style="background: #f8fafc; padding: 20px; border-radius: 8px;">' +
                        '<h4 style="margin: 0 0 16px 0; font-weight: 600;">📋 Contact Information</h4>' +
                        '<div style="line-height: 1.8; font-size: 14px;">' +
                            '<div>📞 ' + selectedDebtor.phone + '</div>' +
                            (selectedDebtor.email ? '<div>✉️ ' + selectedDebtor.email + '</div>' : '') +
                            (selectedDebtor.address ? 
                                '<div>📍 ' + selectedDebtor.address + '<br>' + 
                                selectedDebtor.city + ', ' + selectedDebtor.state + ' ' + selectedDebtor.zipCode + '</div>' 
                                : '') +
                        '</div>' +
                    '</div>' +
                    
                    '<div style="background: #f8fafc; padding: 20px; border-radius: 8px;">' +
                        '<h4 style="margin: 0 0 16px 0; font-weight: 600;">💰 Account Details</h4>' +
                        '<div style="line-height: 1.8; font-size: 14px;">' +
                            '<div style="display: flex; justify-content: space-between;">' +
                                '<span>Current Balance:</span>' +
                                '<span style="font-weight: 700; color: #dc2626;">' + selectedDebtor.currentBalance + '</span>' +
                            '</div>' +
                            (selectedDebtor.originalAmount ? 
                                '<div style="display: flex; justify-content: space-between;">' +
                                    '<span>Original Amount:</span>' +
                                    '<span style="font-weight: 500;">' + selectedDebtor.originalAmount + '</span>' +
                                '</div>' 
                                : '') +
                            '<div style="margin-top: 12px;">' +
                                '<span class="badge ' + selectedDebtor.priority + '">' + selectedDebtor.priority + '</span>' +
                                '<span class="badge ' + selectedDebtor.status + '">' + selectedDebtor.status + '</span>' +
                            '</div>' +
                        '</div>' +
                    '</div>' +
                '</div>' +
                
                '<div>' +
                    '<h4 style="margin: 0 0 16px 0; font-weight: 600;">🕒 Contact History & Activity</h4>' +
                    '<div style="border: 2px dashed #d1d5db; border-radius: 12px; background: #f9fafb; padding: 32px; text-align: center;">' +
                        '<div style="color: #6b7280; margin-bottom: 20px; line-height: 1.6;">' +
                            '<strong>No contact history recorded yet.</strong><br>' +
                            'Click "Log Contact" to record your first interaction with this debtor.' +
                        '</div>' +
                        
                        '<div class="complete-status">' +
                            '<div style="color: #059669; font-weight: 700; margin-bottom: 12px; font-size: 16px;">✅ OBJECTIVE #1 COMPLETE</div>' +
                            '<div style="font-size: 14px; line-height: 1.6; color: #374151; text-align: left;">' +
                                '<strong>Centralized Debtor Contact & Interaction System:</strong><br>' +
                                '✓ 360° debtor view with complete contact information<br>' +
                                '✓ Account list with priority-based visual indicators<br>' +
                                '✓ Interactive debtor selection and detail panels<br>' +
                                '✓ Contact logging interface ready for implementation<br>' +
                                '✓ Real data integration from Compliant Collection system<br>' +
                                '✓ Single-server architecture eliminates dual-server complexity' +
                            '</div>' +
                        '</div>' +
                    '</div>' +
                '</div>';
        }

        function logContact() {
            alert('Contact Logging Interface\\n\\n' +
                'This system would capture:\\n' +
                '• Contact method (phone, email, SMS, letter)\\n' +
                '• Outcome (contact made, voicemail, payment promise, dispute)\\n' +
                '• Call duration and detailed notes\\n' +
                '• Next contact scheduling\\n' +
                '• Compliance tracking and required disclosures\\n\\n' +
                'All interactions are centrally managed and synced with your file system.');
        }
    </script>
</body>
</html>`);
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('🚀 Titan Collection System running on port ' + PORT);
  console.log('🎨 Agent Workspace: http://localhost:' + PORT);
  console.log('📊 API Health: http://localhost:' + PORT + '/api/health'); 
  console.log('✅ Single-server architecture working - preview should be visible!');
});