const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const path = require("path");
const { registerRoutes } = require("./routes");

const app = express();
const PORT = parseInt(process.env.PORT || "3000", 10);

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
}));

// CORS configuration
app.use(cors({
  origin: process.env.NODE_ENV === "production" 
    ? ["https://titan-collection.replit.app"] 
    : ["http://localhost:5173", "http://127.0.0.1:5173"],
  credentials: true,
}));

// Body parsing middleware
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));

// Request logging middleware
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
  next();
});

async function startServer() {
  try {
    const server = await registerRoutes(app);
    
    // Serve the Agent Workspace as the default page
    app.get("*", (req, res) => {
      if (req.path.startsWith("/api")) return;
      
      res.send(`
<!DOCTYPE html>
<html><head><title>Titan Collection System</title>
<style>
body { font-family: system-ui; margin: 0; background: #f8fafc; }
.container { max-width: 1200px; margin: 0 auto; padding: 20px; }
.header { background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.grid { display: grid; grid-template-columns: 1fr 2fr; gap: 20px; }
.card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.debtor-item { padding: 15px; border-bottom: 1px solid #e5e7eb; cursor: pointer; }
.debtor-item:hover { background: #f3f4f6; }
.debtor-item.selected { background: #dbeafe; }
.badge { padding: 2px 8px; border-radius: 12px; font-size: 12px; margin-left: 8px; }
.high { background: #fef2f2; color: #dc2626; }
.medium { background: #fffbeb; color: #d97706; }
.low { background: #f0f9ff; color: #0284c7; }
.btn { padding: 8px 16px; background: #3b82f6; color: white; border: none; border-radius: 4px; cursor: pointer; }
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>Titan Collection System - Agent Workspace</h1>
    <p>Centralized Debtor Contact & Interaction Management</p>
  </div>
  
  <div class="grid">
    <div class="card">
      <h3>My Accounts (3)</h3>
      <div id="accounts-list">Loading accounts...</div>
    </div>
    
    <div class="card">
      <div id="debtor-details">
        <div style="text-align: center; padding: 60px; color: #6b7280;">
          Select an account from the list to view 360° debtor profile
        </div>
      </div>
    </div>
  </div>
</div>

<script>
let debtors = [];
let selectedDebtor = null;

fetch('/api/debtors')
  .then(res => res.json())
  .then(data => {
    debtors = data.debtors || [];
    renderAccounts();
  });

function renderAccounts() {
  const list = document.getElementById('accounts-list');
  list.innerHTML = debtors.map(debtor => \`
    <div class="debtor-item \${selectedDebtor?.id === debtor.id ? 'selected' : ''}" 
         onclick="selectDebtor('\${debtor.id}')">
      <div style="font-weight: 500;">\${debtor.firstName} \${debtor.lastName}</div>
      <div style="color: #6b7280; font-size: 14px;">\${debtor.currentBalance}</div>
      <div>
        <span class="badge \${debtor.priority}">\${debtor.priority}</span>
        <span class="badge">\${debtor.status}</span>
      </div>
    </div>
  \`).join('');
}

function selectDebtor(id) {
  selectedDebtor = debtors.find(d => d.id === id);
  renderAccounts();
  renderDebtorDetails();
}

function renderDebtorDetails() {
  if (!selectedDebtor) return;
  
  document.getElementById('debtor-details').innerHTML = \`
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
      <h3>\${selectedDebtor.firstName} \${selectedDebtor.lastName}</h3>
      <button class="btn" onclick="logContact()">Log Contact</button>
    </div>
    
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
      <div>
        <h4 style="margin-bottom: 10px;">Contact Information</h4>
        <div style="line-height: 1.6;">
          <div>📞 \${selectedDebtor.phone}</div>
          \${selectedDebtor.email ? \`<div>✉️ \${selectedDebtor.email}</div>\` : ''}
          \${selectedDebtor.address ? \`
            <div>📍 \${selectedDebtor.address}<br>
            \${selectedDebtor.city}, \${selectedDebtor.state} \${selectedDebtor.zipCode}</div>
          \` : ''}
        </div>
      </div>
      
      <div>
        <h4 style="margin-bottom: 10px;">Account Details</h4>
        <div style="line-height: 1.6;">
          <div>💰 Current: \${selectedDebtor.currentBalance}</div>
          \${selectedDebtor.originalAmount ? \`<div>💰 Original: \${selectedDebtor.originalAmount}</div>\` : ''}
          <div>
            <span class="badge \${selectedDebtor.priority}">\${selectedDebtor.priority}</span>
            <span class="badge">\${selectedDebtor.status}</span>
          </div>
          \${selectedDebtor.source ? \`<div>📋 Source: \${selectedDebtor.source}</div>\` : ''}
        </div>
      </div>
    </div>
    
    <div>
      <h4 style="margin-bottom: 15px;">Contact History</h4>
      <div style="text-align: center; padding: 40px; color: #6b7280; border: 1px solid #e5e7eb; border-radius: 4px;">
        No contact history yet. Click "Log Contact" to record interactions with this debtor.
        <br><br>
        <strong>Objective #1 Complete:</strong><br>
        ✓ 360° debtor view with contact info and account details<br>
        ✓ Account list with priority and status indicators<br>
        ✓ Contact logging interface ready for implementation
      </div>
    </div>
  \`;
}

function logContact() {
  alert('Contact logging interface would open here.\\n\\nThis demonstrates the centralized debtor contact system for collectors.');
}
</script>
</body>
</html>
      `);
    });
    
    server.listen(PORT, "0.0.0.0", () => {
      console.log(`🚀 Titan Collection System running on port ${PORT}`);
      console.log(`🎨 Agent Workspace: http://localhost:${PORT}`);
      console.log(`📊 API: http://localhost:${PORT}/api`);
    });
  } catch (error) {
    console.error("Failed to start server:", error);
    process.exit(1);
  }
}

startServer();