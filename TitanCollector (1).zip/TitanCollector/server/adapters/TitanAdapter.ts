// Pluggable backend adapter architecture for connecting to different debt systems
import { Debtor, InsertDebtor, ContactLog, InsertContactLog, Payment, InsertPayment } from "../../shared/schema";

export interface ITitanAdapter {
  // Debtor operations
  getDebtors(tenantId: string, page?: number, limit?: number): Promise<{ debtors: Debtor[], total: number }>;
  getDebtor(externalId: string): Promise<Debtor | null>;
  createDebtor(debtor: InsertDebtor): Promise<Debtor>;
  updateDebtor(externalId: string, updates: Partial<Debtor>): Promise<Debtor>;
  
  // Contact operations
  createContactLog(log: InsertContactLog): Promise<ContactLog>;
  getContactHistory(externalId: string): Promise<ContactLog[]>;
  
  // Payment operations
  createPayment(payment: InsertPayment): Promise<Payment>;
  getPaymentHistory(externalId: string): Promise<Payment[]>;
  
  // Compliance operations
  validateContactCompliance(debtorId: string, contactType: string): Promise<{ canContact: boolean, reason?: string }>;
  
  // Webhook operations
  sendWebhook(event: string, data: any): Promise<void>;
}

// Default adapter for Compliant Collection LLC
export class CompliantCollectionAdapter implements ITitanAdapter {
  private baseUrl: string;
  private apiKey: string;
  private tenantId: string;

  constructor(config: { baseUrl: string; apiKey: string; tenantId: string }) {
    this.baseUrl = config.baseUrl;
    this.apiKey = config.apiKey;
    this.tenantId = config.tenantId;
  }

  private async apiRequest(endpoint: string, options: RequestInit = {}) {
    const url = `${this.baseUrl}${endpoint}`;
    const response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.apiKey}`,
        'X-Tenant-ID': this.tenantId,
        ...options.headers,
      },
    });

    if (!response.ok) {
      throw new Error(`API request failed: ${response.status} ${response.statusText}`);
    }

    return response.json();
  }

  async getDebtors(tenantId: string, page = 1, limit = 50): Promise<{ debtors: Debtor[], total: number }> {
    try {
      const data = await this.apiRequest(`/api/debtors?page=${page}&limit=${limit}&tenant=${tenantId}`);
      return {
        debtors: data.debtors || [],
        total: data.total || 0,
      };
    } catch (error) {
      console.error('Error fetching debtors from external API:', error);
      // Return empty result if external API fails
      return { debtors: [], total: 0 };
    }
  }

  async getDebtor(externalId: string): Promise<Debtor | null> {
    try {
      return await this.apiRequest(`/api/debtors/${externalId}`);
    } catch (error) {
      console.error('Error fetching debtor from external API:', error);
      return null;
    }
  }

  async createDebtor(debtor: InsertDebtor): Promise<Debtor> {
    return this.apiRequest('/api/debtors', {
      method: 'POST',
      body: JSON.stringify(debtor),
    });
  }

  async updateDebtor(externalId: string, updates: Partial<Debtor>): Promise<Debtor> {
    return this.apiRequest(`/api/debtors/${externalId}`, {
      method: 'PATCH',
      body: JSON.stringify(updates),
    });
  }

  async createContactLog(log: InsertContactLog): Promise<ContactLog> {
    return this.apiRequest('/api/contact-logs', {
      method: 'POST',
      body: JSON.stringify(log),
    });
  }

  async getContactHistory(externalId: string): Promise<ContactLog[]> {
    try {
      const data = await this.apiRequest(`/api/debtors/${externalId}/contacts`);
      return data.contacts || [];
    } catch (error) {
      console.error('Error fetching contact history from external API:', error);
      return [];
    }
  }

  async createPayment(payment: InsertPayment): Promise<Payment> {
    return this.apiRequest('/api/payments', {
      method: 'POST',
      body: JSON.stringify(payment),
    });
  }

  async getPaymentHistory(externalId: string): Promise<Payment[]> {
    try {
      const data = await this.apiRequest(`/api/debtors/${externalId}/payments`);
      return data.payments || [];
    } catch (error) {
      console.error('Error fetching payment history from external API:', error);
      return [];
    }
  }

  async validateContactCompliance(debtorId: string, contactType: string): Promise<{ canContact: boolean, reason?: string }> {
    try {
      return await this.apiRequest(`/api/compliance/validate`, {
        method: 'POST',
        body: JSON.stringify({ debtorId, contactType }),
      });
    } catch (error) {
      console.error('Error validating compliance:', error);
      // Default to allowing contact if compliance check fails
      return { canContact: true, reason: 'Compliance check unavailable' };
    }
  }

  async sendWebhook(event: string, data: any): Promise<void> {
    try {
      await this.apiRequest('/api/webhooks', {
        method: 'POST',
        body: JSON.stringify({ event, data, timestamp: new Date().toISOString() }),
      });
    } catch (error) {
      console.error('Error sending webhook:', error);
      // Don't throw error for webhook failures
    }
  }
}

// Factory for creating adapters based on tenant configuration
export class AdapterFactory {
  static createAdapter(tenantConfig: { 
    apiBaseUrl?: string; 
    apiKey?: string; 
    tenantId: string;
    adapterType?: string;
  }): ITitanAdapter {
    // Default to CompliantCollectionAdapter
    const adapterType = tenantConfig.adapterType || 'compliant-collection';
    
    switch (adapterType) {
      case 'compliant-collection':
        return new CompliantCollectionAdapter({
          baseUrl: tenantConfig.apiBaseUrl || 'https://api.compliantcollection.com',
          apiKey: tenantConfig.apiKey || '',
          tenantId: tenantConfig.tenantId,
        });
      
      // Add more adapters here for other debt systems
      // case 'other-crm':
      //   return new OtherCrmAdapter(config);
      
      default:
        throw new Error(`Unknown adapter type: ${adapterType}`);
    }
  }
}