import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: "healthy", 
      timestamp: new Date().toISOString(),
      service: "Titan Collection System"
    });
  });

  // Dashboard stats endpoint
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const tenantId = req.query.tenant as string || "default";
      const stats = await storage.getDashboardStats(tenantId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Debtors endpoint
  app.get("/api/debtors", async (req, res) => {
    try {
      const tenantId = req.query.tenant as string || "default";
      const debtors = await storage.getDebtors(tenantId);
      res.json(debtors);
    } catch (error) {
      console.error("Error fetching debtors:", error);
      res.status(500).json({ message: "Failed to fetch debtors" });
    }
  });

  // Test endpoint for Compliant Collection LLC integration
  app.get("/api/integration/test", async (req, res) => {
    res.json({
      message: "Integration endpoint ready for Compliant Collection LLC",
      timestamp: new Date().toISOString(),
      status: "ready"
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}