// Interface for storage operations
export interface IStorage {
  // Dashboard stats
  getDashboardStats(tenantId: string): Promise<DashboardStats>;
  
  // Debtor operations
  getDebtors(tenantId: string): Promise<{ debtors: Debtor[] }>;
}

export interface DashboardStats {
  totalDebtors: number;
  totalOwed: string;
  needContact: number;
  collected: string;
}

export interface Debtor {
  id: string;
  firstName: string;
  lastName: string;
  phone: string;
  currentBalance: string;
  status: string;
  priority: string;
  nextContactDate?: string;
}

export class MemStorage implements IStorage {
  private sampleDebtors: Debtor[] = [
    {
      id: "1",
      firstName: "John",
      lastName: "Smith",
      phone: "(555) 123-4567",
      currentBalance: "2,450.00",
      status: "active",
      priority: "high",
      nextContactDate: new Date().toISOString(),
    },
    {
      id: "2",
      firstName: "Sarah",
      lastName: "Johnson",
      phone: "(555) 987-6543",
      currentBalance: "1,200.00",
      status: "active",
      priority: "medium",
      nextContactDate: new Date(Date.now() + 86400000).toISOString(), // tomorrow
    },
    {
      id: "3",
      firstName: "Michael",
      lastName: "Brown",
      phone: "(555) 456-7890",
      currentBalance: "3,750.00",
      status: "active",
      priority: "high",
      nextContactDate: new Date().toISOString(),
    },
    {
      id: "4",
      firstName: "Lisa",
      lastName: "Davis",
      phone: "(555) 321-9876",
      currentBalance: "875.00",
      status: "dispute",
      priority: "low",
    },
    {
      id: "5",
      firstName: "Robert",
      lastName: "Wilson",
      phone: "(555) 654-3210",
      currentBalance: "5,200.00",
      status: "legal",
      priority: "high",
      nextContactDate: new Date().toISOString(),
    }
  ];

  async getDashboardStats(tenantId: string): Promise<DashboardStats> {
    const totalOwed = this.sampleDebtors.reduce((sum, debtor) => {
      return sum + parseFloat(debtor.currentBalance.replace(",", ""));
    }, 0);

    const needContact = this.sampleDebtors.filter(debtor => {
      if (!debtor.nextContactDate) return false;
      const contactDate = new Date(debtor.nextContactDate);
      const today = new Date();
      return contactDate.toDateString() === today.toDateString();
    }).length;

    return {
      totalDebtors: this.sampleDebtors.length,
      totalOwed: totalOwed.toLocaleString("en-US", { minimumFractionDigits: 2 }),
      needContact,
      collected: "1,250.00"
    };
  }

  async getDebtors(tenantId: string): Promise<{ debtors: Debtor[] }> {
    return { debtors: this.sampleDebtors };
  }
}

export const storage = new MemStorage();