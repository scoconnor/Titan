import { Debtor, ContactLog, Payment } from "../../shared/schema";

// Server-side integration with the file application
export class FileSystemIntegration {
  private baseUrl: string;
  private apiKey: string;

  constructor(baseUrl: string, apiKey: string) {
    this.baseUrl = baseUrl;
    this.apiKey = apiKey;
  }

  private async apiRequest(endpoint: string, options: RequestInit = {}) {
    const url = `${this.baseUrl}${endpoint}`;
    const response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.apiKey}`,
        'X-Source': 'titan-collection-system',
        ...options.headers,
      },
    });

    if (!response.ok) {
      throw new Error(`File system API request failed: ${response.status} ${response.statusText}`);
    }

    return response.json();
  }

  // Sync debtor data with file system
  async syncDebtorToFileSystem(debtor: Debtor): Promise<any> {
    try {
      // First, try to find existing file
      const existingFiles = await this.findDebtorFile(debtor.firstName, debtor.lastName, debtor.phone);
      
      let fileId: string;
      
      if (existingFiles && existingFiles.length > 0) {
        // Update existing file
        fileId = existingFiles[0].id;
        await this.updateDebtorFile(fileId, debtor);
      } else {
        // Create new file
        const newFile = await this.createDebtorFile(debtor);
        fileId = newFile.id;
      }

      return { fileId, action: existingFiles?.length > 0 ? 'updated' : 'created' };
    } catch (error) {
      console.error('Failed to sync debtor to file system:', error);
      throw error;
    }
  }

  // Create a new file for the debtor
  async createDebtorFile(debtor: Debtor): Promise<any> {
    const fileData = {
      clientName: `${debtor.firstName} ${debtor.lastName}`,
      fileType: 'debt-collection',
      status: this.mapDebtorStatusToFileStatus(debtor.status),
      priority: debtor.priority,
      assignedTo: debtor.assignedCollectorId,
      tags: ['debt-collection', 'titan-system'],
      metadata: {
        titanDebtorId: debtor.id,
        externalId: debtor.externalId,
        originalAmount: debtor.originalAmount,
        currentBalance: debtor.currentBalance,
        interestRate: debtor.interestRate,
        contactInfo: {
          phone: debtor.phone,
          alternatePhone: debtor.alternatePhone,
          email: debtor.email,
        },
        address: {
          street: debtor.address,
          city: debtor.city,
          state: debtor.state,
          zipCode: debtor.zipCode,
        },
        debtInfo: {
          originalAmount: debtor.originalAmount,
          currentBalance: debtor.currentBalance,
          lastContactDate: debtor.lastContactDate,
          nextContactDate: debtor.nextContactDate,
          doNotCall: debtor.doNotCall,
        }
      }
    };

    return this.apiRequest('/api/files', {
      method: 'POST',
      body: JSON.stringify(fileData),
    });
  }

  // Update existing file with debtor data
  async updateDebtorFile(fileId: string, debtor: Debtor): Promise<any> {
    const updateData = {
      status: this.mapDebtorStatusToFileStatus(debtor.status),
      priority: debtor.priority,
      assignedTo: debtor.assignedCollectorId,
      metadata: {
        titanDebtorId: debtor.id,
        currentBalance: debtor.currentBalance,
        lastContactDate: debtor.lastContactDate,
        nextContactDate: debtor.nextContactDate,
        doNotCall: debtor.doNotCall,
        lastSyncDate: new Date().toISOString(),
      }
    };

    return this.apiRequest(`/api/files/${fileId}`, {
      method: 'PATCH',
      body: JSON.stringify(updateData),
    });
  }

  // Find existing file by debtor information
  async findDebtorFile(firstName: string, lastName: string, phone?: string): Promise<any[]> {
    const searchQuery = `${firstName} ${lastName} ${phone || ''}`.trim();
    const response = await this.apiRequest(`/api/files/search?q=${encodeURIComponent(searchQuery)}&type=debt-collection`);
    return response.files || [];
  }

  // Upload contact log as document
  async uploadContactLog(fileId: string, contactLog: ContactLog): Promise<any> {
    const logData = {
      type: 'contact-log',
      timestamp: contactLog.createdAt,
      contactType: contactLog.contactType,
      contactMethod: contactLog.contactMethod,
      duration: contactLog.duration,
      outcome: contactLog.outcome,
      notes: contactLog.notes,
      collectorId: contactLog.collectorId,
      complianceInfo: {
        disclosureGiven: contactLog.disclosureGiven,
        miniMirandaRead: contactLog.miniMirandaRead,
      },
      nextAction: contactLog.nextAction,
      nextContactDate: contactLog.nextContactDate,
    };

    // Create a document entry
    const documentData = {
      fileName: `contact-log-${contactLog.createdAt.toISOString()}.json`,
      documentType: 'contact-log',
      description: `${contactLog.contactType} contact - ${contactLog.outcome}`,
      content: JSON.stringify(logData, null, 2),
      metadata: {
        titanContactLogId: contactLog.id,
        contactType: contactLog.contactType,
        outcome: contactLog.outcome,
        duration: contactLog.duration,
      }
    };

    return this.apiRequest(`/api/files/${fileId}/documents`, {
      method: 'POST',
      body: JSON.stringify(documentData),
    });
  }

  // Upload payment record as document
  async uploadPaymentRecord(fileId: string, payment: Payment): Promise<any> {
    const paymentData = {
      type: 'payment-record',
      timestamp: payment.createdAt,
      amount: payment.amount,
      paymentMethod: payment.paymentMethod,
      paymentDate: payment.paymentDate,
      transactionId: payment.transactionId,
      status: payment.status,
      notes: payment.notes,
    };

    const documentData = {
      fileName: `payment-${payment.createdAt.toISOString()}.json`,
      documentType: 'payment-record',
      description: `Payment of $${payment.amount} via ${payment.paymentMethod}`,
      content: JSON.stringify(paymentData, null, 2),
      metadata: {
        titanPaymentId: payment.id,
        amount: payment.amount,
        paymentMethod: payment.paymentMethod,
        status: payment.status,
      }
    };

    return this.apiRequest(`/api/files/${fileId}/documents`, {
      method: 'POST',
      body: JSON.stringify(documentData),
    });
  }

  // Map debtor status to file system status
  private mapDebtorStatusToFileStatus(debtorStatus: string): string {
    switch (debtorStatus) {
      case 'active':
        return 'active';
      case 'paid':
        return 'closed';
      case 'settled':
        return 'resolved';
      case 'disputed':
        return 'on-hold';
      default:
        return 'active';
    }
  }

  // Webhook endpoint for receiving updates from file system
  async handleFileSystemWebhook(webhookData: any): Promise<void> {
    try {
      console.log('Received file system webhook:', webhookData);
      
      // Handle different webhook events
      switch (webhookData.event) {
        case 'file.updated':
          await this.handleFileUpdated(webhookData.data);
          break;
        case 'file.status_changed':
          await this.handleFileStatusChanged(webhookData.data);
          break;
        case 'document.uploaded':
          await this.handleDocumentUploaded(webhookData.data);
          break;
        default:
          console.log('Unhandled webhook event:', webhookData.event);
      }
    } catch (error) {
      console.error('Error handling file system webhook:', error);
      throw error;
    }
  }

  private async handleFileUpdated(fileData: any): Promise<void> {
    // Update corresponding debtor in Titan system
    const titanDebtorId = fileData.metadata?.titanDebtorId;
    if (titanDebtorId) {
      // Update debtor with file system changes
      console.log(`Updating Titan debtor ${titanDebtorId} from file system update`);
      // Implementation would update storage here
    }
  }

  private async handleFileStatusChanged(fileData: any): Promise<void> {
    // Sync status changes back to Titan
    const titanDebtorId = fileData.metadata?.titanDebtorId;
    if (titanDebtorId) {
      console.log(`Syncing status change for debtor ${titanDebtorId}`);
      // Implementation would update debtor status here
    }
  }

  private async handleDocumentUploaded(documentData: any): Promise<void> {
    // Process new documents that might be relevant to debt collection
    console.log('New document uploaded to file system:', documentData.fileName);
  }
}