class MemStorage {
  constructor() {
    // Initialize sample debtors first
    this.initializeSampleDebtors();
    
    // Contact logs and payment storage
    this.contactLogs = [];
    this.payments = [];
  }
  
  initializeSampleDebtors() {
    // No sample data - only real data from Compliant Collection
    this.sampleDebtors = [];
  }

  async getDebtors(tenantId) {
    // Only return debtors from Compliant Collection (source: "compliant-collection")
    const compliantDebtors = this.sampleDebtors.filter(debtor => 
      debtor.source === "compliant-collection"
    );
    return { debtors: compliantDebtors };
  }

  async addExternalDebtors(externalDebtors) {
    // Add external debtors to our sample data
    externalDebtors.forEach(debtor => {
      // Check if debtor already exists (by external ID)
      const existingIndex = this.sampleDebtors.findIndex(d => d.externalId === debtor.externalId);
      
      if (existingIndex >= 0) {
        // Update existing debtor
        this.sampleDebtors[existingIndex] = { ...this.sampleDebtors[existingIndex], ...debtor };
      } else {
        // Add new debtor
        this.sampleDebtors.push(debtor);
      }
    });

    console.log(`Updated storage with ${externalDebtors.length} external debtors. Total: ${this.sampleDebtors.length}`);
    return this.sampleDebtors;
  }

  async getContactLogs(debtorId) {
    return this.contactLogs.filter(log => log.debtorId === debtorId)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  async addContactLog(contactLogData) {
    const newLog = {
      id: Date.now().toString(),
      ...contactLogData,
      createdAt: new Date().toISOString(),
    };
    this.contactLogs.push(newLog);
    return newLog;
  }

  async updateDebtorNextContact(debtorId, nextContactDate) {
    const debtorIndex = this.sampleDebtors.findIndex(d => d.id === debtorId);
    if (debtorIndex >= 0) {
      this.sampleDebtors[debtorIndex].nextContactDate = nextContactDate;
    }
  }

  // Payment storage
  async getPayments(debtorId) {
    return this.payments.filter(payment => payment.debtorId === debtorId)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  async addPayment(paymentData) {
    const newPayment = {
      id: Date.now().toString(),
      ...paymentData,
      createdAt: new Date().toISOString(),
    };
    this.payments.push(newPayment);
    
    // Update debtor balance
    const debtorIndex = this.sampleDebtors.findIndex(d => d.id === paymentData.debtorId);
    if (debtorIndex >= 0) {
      const currentBalance = parseFloat(this.sampleDebtors[debtorIndex].currentBalance.replace(/[,$]/g, ''));
      const paymentAmount = parseFloat(paymentData.amount);
      const newBalance = (currentBalance - paymentAmount).toFixed(2);
      this.sampleDebtors[debtorIndex].currentBalance = newBalance;
      
      // Update status if paid off
      if (parseFloat(newBalance) <= 0) {
        this.sampleDebtors[debtorIndex].status = 'paid';
      }
    }
    
    return newPayment;
  }
}

const storage = new MemStorage();
module.exports = { storage };