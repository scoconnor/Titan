const { createServer } = require("http");
const { storage } = require("./storage");

async function registerRoutes(app) {
  
  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: "healthy", 
      timestamp: new Date().toISOString(),
      service: "Titan Collection System"
    });
  });

  // Dashboard stats endpoint
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const tenantId = req.query.tenant || "default";
      const stats = await storage.getDashboardStats(tenantId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Debtors endpoint
  app.get("/api/debtors", async (req, res) => {
    try {
      const tenantId = req.query.tenant || "default";
      const debtors = await storage.getDebtors(tenantId);
      res.json(debtors);
    } catch (error) {
      console.error("Error fetching debtors:", error);
      res.status(500).json({ message: "Failed to fetch debtors" });
    }
  });

  // Test endpoint for Compliant Collection LLC integration
  app.get("/api/integration/test", async (req, res) => {
    res.json({
      message: "Integration endpoint ready for Compliant Collection LLC",
      timestamp: new Date().toISOString(),
      status: "ready"
    });
  });

  // Debug endpoint to show what we're getting from your API
  app.get("/api/integration/debug-response", async (req, res) => {
    try {
      const testUrl = "https://www.compliantcollection.com/api/borrowers";
      console.log("Testing:", testUrl);
      
      const response = await fetch(testUrl, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'User-Agent': 'Titan-Collection-System/1.0'
        }
      });

      const responseText = await response.text();
      
      res.json({
        url: testUrl,
        status: response.status,
        statusText: response.statusText,
        headers: Object.fromEntries(response.headers.entries()),
        responseLength: responseText.length,
        isJson: response.headers.get('content-type')?.includes('json'),
        responsePreview: responseText.substring(0, 500),
        suggestion: response.headers.get('content-type')?.includes('json') 
          ? "Response is JSON - integration should work!"
          : "Response is HTML - check if API endpoints are configured to return JSON"
      });
    } catch (error) {
      res.status(500).json({
        error: error.message,
        suggestion: "Could not connect to your system"
      });
    }
  });

  // Pull debtors from Compliant Collection system
  app.post("/api/integration/pull-debtors", async (req, res) => {
    try {
      console.log("Attempting to pull debtors from www.compliantcollection.com");
      
      // Try to connect to Compliant Collection API
      const compliantCollectionUrl = "https://www.compliantcollection.com";
      
      // Try different API endpoints that might contain debtor data
      const testEndpoints = [
        '/api/borrowers',
        '/api/debtors', 
        '/api/accounts',
        '/api/files',
        '/api/clients',
        '/api/data/files',
        '/api/v1/borrowers',
        '/api/v1/debtors',
        '/api/data'
      ];
      
      let response = null;
      let workingEndpoint = null;
      
      for (const endpoint of testEndpoints) {
        try {
          console.log(`Testing endpoint: ${compliantCollectionUrl}${endpoint}`);
          response = await fetch(`${compliantCollectionUrl}${endpoint}`, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
              'User-Agent': 'Titan-Collection-System/1.0',
              'X-Source': 'titan-integration',
              'X-Requested-With': 'XMLHttpRequest'
            }
          });
          
          if (response.ok) {
            const contentType = response.headers.get('content-type');
            if (contentType && contentType.includes('application/json')) {
              workingEndpoint = endpoint;
              console.log(`Found working JSON endpoint: ${endpoint}`);
              break;
            } else {
              console.log(`${endpoint}: Got ${response.status} but content-type is ${contentType}`);
            }
          } else {
            console.log(`${endpoint}: HTTP ${response.status}`);
          }
        } catch (error) {
          console.log(`${endpoint}: Error - ${error.message}`);
        }
      }

      if (!response || !response.ok || !workingEndpoint) {
        return res.status(502).json({ 
          message: "Could not find working API endpoint on Compliant Collection system",
          details: `Tested endpoints: ${testEndpoints.join(', ')}`,
          url: compliantCollectionUrl,
          suggestion: "Ensure API endpoints return JSON content-type"
        });
      }

      const debtorFiles = await response.json();
      console.log(`Found debtor data:`, debtorFiles);

      // Handle different possible response formats
      let dataArray = [];
      if (Array.isArray(debtorFiles)) {
        dataArray = debtorFiles;
      } else if (debtorFiles.debtors) {
        dataArray = debtorFiles.debtors;
      } else if (debtorFiles.borrowers) {
        dataArray = debtorFiles.borrowers;
      } else if (debtorFiles.files) {
        dataArray = debtorFiles.files;
      } else if (debtorFiles.data) {
        dataArray = debtorFiles.data;
      }

      console.log(`Processing ${dataArray.length || 0} records`);

      // Convert file system data to Titan debtor format
      const convertedDebtors = dataArray.map((item, index) => ({
        id: `cc-${item.id || item._id || index}`,
        externalId: item.id || item._id || `ext-${index}`,
        firstName: item.firstName || item.first_name || item.clientName?.split(' ')[0] || item.name?.split(' ')[0] || 'Unknown',
        lastName: item.lastName || item.last_name || item.clientName?.split(' ').slice(1).join(' ') || item.name?.split(' ').slice(1).join(' ') || 'Unknown',
        phone: item.phone || item.phoneNumber || item.contact?.phone || item.metadata?.phone || '',
        email: item.email || item.emailAddress || item.contact?.email || item.metadata?.email || '',
        currentBalance: item.currentBalance || item.balance || item.amount || item.debt || item.metadata?.currentBalance || '0.00',
        originalAmount: item.originalAmount || item.originalBalance || item.principal || item.metadata?.originalAmount || item.currentBalance || '0.00',
        status: mapExternalStatus(item.status || 'active'),
        priority: item.priority || 'medium',
        nextContactDate: item.nextContactDate || item.next_contact || item.metadata?.nextContactDate,
        lastContactDate: item.lastContactDate || item.last_contact || item.metadata?.lastContactDate,
        source: 'compliant-collection',
        assignedCollectorId: item.assignedTo || item.collector || item.agent,
        address: item.address || item.street || item.metadata?.address,
        city: item.city || item.metadata?.city,
        state: item.state || item.metadata?.state,
        zipCode: item.zipCode || item.zip || item.metadata?.zipCode
      }));

      // Add to Titan storage
      await storage.addExternalDebtors(convertedDebtors);

      res.json({
        message: `Successfully pulled ${convertedDebtors.length} debtors from Compliant Collection`,
        debtors: convertedDebtors,
        workingEndpoint: workingEndpoint,
        timestamp: new Date().toISOString()
      });

    } catch (error) {
      console.error("Error pulling debtors from Compliant Collection:", error);
      res.status(500).json({ 
        message: "Failed to pull debtors from Compliant Collection",
        error: error.message,
        suggestion: "Ensure www.compliantcollection.com is accessible and has API endpoints"
      });
    }
  });

  // Check connection to Compliant Collection
  app.get("/api/integration/check-connection", async (req, res) => {
    try {
      const compliantCollectionUrl = "https://www.compliantcollection.com";
      
      const response = await fetch(compliantCollectionUrl, {
        method: 'HEAD',
        headers: {
          'User-Agent': 'Titan-Collection-System/1.0'
        }
      });

      res.json({
        status: response.ok ? "connected" : "unreachable",
        statusCode: response.status,
        url: compliantCollectionUrl,
        timestamp: new Date().toISOString()
      });

    } catch (error) {
      res.json({
        status: "error",
        error: error.message,
        url: "https://www.compliantcollection.com",
        timestamp: new Date().toISOString()
      });
    }
  });

  // Contact logs endpoints for Agent interface
  app.get("/api/contact-logs/:debtorId", async (req, res) => {
    try {
      const { debtorId } = req.params;
      const contactLogs = await storage.getContactLogs(debtorId);
      res.json(contactLogs);
    } catch (error) {
      console.error("Error fetching contact logs:", error);
      res.status(500).json({ message: "Failed to fetch contact logs" });
    }
  });

  app.post("/api/contact-logs", async (req, res) => {
    try {
      const contactLogData = req.body;
      const newContactLog = await storage.addContactLog(contactLogData);
      
      // Update debtor's next contact date if provided
      if (contactLogData.nextContactDate) {
        await storage.updateDebtorNextContact(contactLogData.debtorId, contactLogData.nextContactDate);
      }
      
      res.json(newContactLog);
    } catch (error) {
      console.error("Error adding contact log:", error);
      res.status(500).json({ message: "Failed to add contact log" });
    }
  });

  // Payment management endpoints
  app.get("/api/payments/:debtorId", async (req, res) => {
    try {
      const { debtorId } = req.params;
      const payments = await storage.getPayments(debtorId);
      res.json(payments);
    } catch (error) {
      console.error("Error fetching payments:", error);
      res.status(500).json({ message: "Failed to fetch payments" });
    }
  });

  app.post("/api/payments", async (req, res) => {
    try {
      const paymentData = req.body;
      const newPayment = await storage.addPayment(paymentData);
      res.json(newPayment);
    } catch (error) {
      console.error("Error processing payment:", error);
      res.status(500).json({ message: "Failed to process payment" });
    }
  });

  // Helper function to map external status to Titan status
  function mapExternalStatus(externalStatus) {
    const statusMap = {
      'active': 'active',
      'open': 'active', 
      'pending': 'active',
      'closed': 'paid',
      'paid': 'paid',
      'settled': 'settled',
      'dispute': 'dispute',
      'disputed': 'dispute',
      'legal': 'legal',
      'collection': 'active'
    };
    return statusMap[externalStatus?.toLowerCase()] || 'active';
  }

  const httpServer = createServer(app);
  return httpServer;
}

module.exports = { registerRoutes };